cat result.txt | while read i;
do
   HOSTIP=`echo ${i} |awk '{print $1}`
   TNNU=`echo ${i} |awk '{print $4}` 
if [ ${TNNU} -gt 0 ]
   then 
( sleep 1
echo '\004'
#echo "exit"
) | telnet ${HOSTIP} >out.txt 2>>err.txt &
Pid=$!
sleep 5
ps -l | awk '{print $4}' | grep -q $Pid
  if [ $? -gt 0 ];
  then
    echo  "telnet ${HOSTIP}  kill $Pid"
    kill -9 $Pid  
  fi
   cat out.txt |grep -q -i "HP-UX"  #HP UNIX
   if [ $? -eq 0 ];
   then 
    echo  ${HOSTIP}"  "`cat out.txt |grep -i "HP-UX"` >>outtelnet.txt
   else
      cat out.txt |grep -q " login:"
      if [ $? -eq 0 ];
        then
           echo  ${HOSTIP}"  "`cat out.txt |grep  " login:"` >>outtelnet.txt    
         else 
           cat out.txt |grep -q "telnet " 
           if [ $? -eq 0 ];
             then
                echo  ${HOSTIP}"  "`cat out.txt |grep " telnet "` >>outtelnet.txt
             else
               cat out.txt |grep -q -i Microsoft
               if [ $? -eq 0 ];
                  then 
                    echo  ${HOSTIP}"  "`cat out.txt |grep -i Microsoft` >>outtelnet.txt
               fi
            fi
      fi
    fi
fi
done



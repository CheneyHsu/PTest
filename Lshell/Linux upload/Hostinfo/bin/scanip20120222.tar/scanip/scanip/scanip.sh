export LANG=zh_CN.gb18030 
scanipFile=scanip.txt
resultFile=result.txt
timeOutSnd=5
if [ $# -eq 1 ] ; then 
  timeOutSnd=$1 
fi 

if [ $# -eq 2 ] ; then 
  timeOutSnd=$1 
  scanipFile=$2 
fi 

if [ $# -ge 3 ] ; then 
  timeOutSnd=$1 
  scanipFile=$2 
  resultFile=$3
fi 

date
/opt/java6/bin/java -classpath scanip.jar ScanPort $timeOutSnd $scanipFile $resultFile 
date

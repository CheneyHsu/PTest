#!/bin/sh
sqlplus -s  dbsnmp/dbsnmp << END
select 'hello hou' from dual;
quit;
END
echo "Press ENTER button to back"
read $CON

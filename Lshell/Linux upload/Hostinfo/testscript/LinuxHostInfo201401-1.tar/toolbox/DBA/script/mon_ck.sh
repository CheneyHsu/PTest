#!/bin/sh
sqlplus -s  dbsnmp/dbsnmp << END
select 'hello mon' from dual;
quit;
END
echo "Press ENTER button to back"
read $CON

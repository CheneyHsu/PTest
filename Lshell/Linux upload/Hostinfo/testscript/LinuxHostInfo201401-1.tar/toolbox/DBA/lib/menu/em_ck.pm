package lib::menu::em_ck;
use warnings;
use strict;

my @cT;

BEGIN {
        use XML::Simple;

        my $xmlfile = "./conf/conf.xml";

        my $casesT = XML::Simple->new(ForceArray => 1);
        my $caseT  = $casesT->XMLin($xmlfile);

        @cT = @{$caseT->{"option"}};
}

sub emergency_check {
        foreach my $t (@cT) {
                for  my $m ($t->{"emergency"}) {
                        do {
                                system 'clear';
                                print "------------------------------------------------------\n";
                                my @n = @{@$m[0]->{"file"}};
                                my $arr = \@n;
                                for (my $i=0;$i<=$#$arr;$i++) {
                                        print $i . ".   " . @$arr[$i]->{"name"}[0]."\n";
                                }
                                print "    (X|x) to back\n";
                                print "------------------------------------------------------\n";
                                print "Enter your choice: ";
                                my $number = <STDIN>;
                                chomp($number);
                                if ($number =~ /[A-Za-z]/) {
                                        if ($number eq "x" or $number eq "X") {
                                                return;
                                        }
                                        else {
                                                redo;
                                        }
                                }
                                if ($number =~ /[0-9]/) {
                                        if ($number <0 or $number>$#$arr) {
                                                print "Out of scope or input error.\n";
                                                exit;
                                        }
                                        my $com=@$arr[$number]->{"location"}[0];
                                        system $com;
                                }
                        }while (1)
                }
        }
}

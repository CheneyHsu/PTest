#!/usr/bin/env perl
use warnings;
use strict;

use XML::Simple;
use lib "lib";

use menu::day_ck;
use menu::em_ck;
my $xmlfile = "./conf/conf.xml";

my $casesT = XML::Simple->new(ForceArray => 1);
my $caseT  = $casesT->XMLin($xmlfile);

my @cT = @{$caseT->{"option"}};

foreach my $t (@cT) {
        do {
                system 'clear';
                print "------------------------------------------------------\n";
                print "       Database Check Script\n\n";
                for my $m ($t->{"first"}) {
                        for (my $i=0;$i<=$#$m;$i++) {
                                print "   " . $i . "\.  ".@$m[$i]->{"name"}[0]."\n";
                        }
                        print "    (Q|q) to quit\n";
                        print "------------------------------------------------------\n";
                        print "Enter your choice: ";
                        my $number = <STDIN>;
                        chomp($number);
                        if ($number =~ /[A-Za-z]/) {
                                if ($number eq "q" or $number eq "Q") {
                                        print "\n";
                                        exit;
                                }
                                else {
                                        print "Input error\n";
                                        exit;
                                }
                        }
                        if ($number =~ /[0-9]/) {
                                if ($number < 0 or $number > $#$m ) {
                                        print "Out of scope or input error.\n";
                                        exit;
                                }
                                if ($number == 0) {
                                        lib::menu::day_ck::daily_check();       
                                }
                                if ($number == 1) {
                                        lib::menu::em_ck::emergency_check();       
                                }
                        }
                }
        } while (1);
}

select '#306-SGA Resize Operations: '||count(*) output, case when count(*)<6 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'306-l_p_sgaresize_info.log' DETAIL
from v$sga_resize_ops where oper_mode='IMMEDIATE' and start_time>=sysdate-(1/24)
;
#!/bin/sh

filepath=$(cd "$(dirname "$0")";pwd)
cd $filepath
nohup $ORACLE_HOME/bin/sqlplus -S dbsnmp/dbsnmp @l_dba_exam.sql > l_dba_exam.out&
$ORACLE_HOME/bin/sqlplus -S dbsnmp/dbsnmp @s_dba_exam.sql $filepath

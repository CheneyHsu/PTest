select '#304-Lock Waiting Sessions: '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'304-l_p_lock_info.log' DETAIL
from v$session where status='ACTIVE' and type='USER' and state='WAITING' and event like 'enq%'
;
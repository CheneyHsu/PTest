set pagesize 999 linesize 131 feed off verify off trims off
col output for a40
col result for a9
col detail for a60
col instance_name for a16
col current_time for a26
col trace_name new_value alert_log noprint
col tool_version for a12
col log_directory for a32

define log_dir='&1/'

define script_ver=1.0.0

select instance_name,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') current_time,'&script_ver' tool_version,'&&log_dir' log_directory,
value||'/alert_'||instance_name||'.log' trace_name from v$instance,v$parameter
where name='background_dump_dest';

set heading on
@@s_a_inst_status.sql
set heading off
@@s_a_dbfile_info.sql
@@s_a_redo_info.sql
@@s_a_invobj_info.sql
@@s_a_invind_info.sql
@@s_s_tbs_info.sql
@@s_s_undo_info.sql
@@s_s_temp_info.sql
@@s_p_actsess_info.sql
@@s_p_actsess_cpu.sql
@@s_p_actsess_latch.sql
@@s_p_lock_enq.sql
@@s_p_longrun_sql.sql
@@s_p_sgaresize_info.sql
@@s_a_alertlog.sql

exit


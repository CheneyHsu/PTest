
select t.tablespace_name,sum(f.bytes)/1024/1024 
from dba_tablespaces t,dba_data_files f
where t.tablespace_name=f.tablespace_name
and t.contents='UNDO'
group by t.tablespace_name
;

select tablespace_name,status,sum(bytes)/1024/1024 from dba_undo_extents
group by tablespace_name,status
;

select s.sid,t.xidusn,t.xidsqn,round(t.used_ublk*8/1024,2) undo_MB,used_urec undo_records,
sum(u.bytes)/1024/1024 ACTIVE_EXTENT_mb,
s.machine,s.program,s.status,s.event,l.sql_text 
from v$transaction t,v$session s,v$sqlstats l,dba_undo_extents u
where t.ses_addr=s.saddr
and nvl(s.sql_id,s.prev_sql_id)=l.sql_id(+)
and u.segment_name like '_SYSSMU'||t.xidusn||'%$'
and u.status='ACTIVE' 
group by s.sid, t.xidusn, t.xidsqn, round(t.used_ublk*8/1024,2), used_urec, s.machine, s.program, s.status, s.event, l.sql_text
order by undo_MB
; 
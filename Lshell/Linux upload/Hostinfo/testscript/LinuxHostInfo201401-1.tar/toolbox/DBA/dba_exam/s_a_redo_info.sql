select '#102-Invalid Redo Logs: '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'102-l_a_redo_info.log' DETAIL from 
(
select g.thread#,g.group#,g.members,g.archived,g.sequence#,f.type,f.member,
       g.bytes,g.status,f.status file_stutus,g.first_time,g.first_change#
  from v$logfile f,v$log g
 where f.group#=g.group#
   and f.status='Invalid'
) 
;

select g.thread#,g.group#,g.members,g.archived,g.sequence#,f.type,f.member,
       g.bytes,g.status,f.status file_stutus,g.first_time,g.first_change#
  from v$logfile f,v$log g
 where f.group#=g.group#
 order by g.thread#,g.group#,member;
select '#301-Active Session Rate: '||rate||'%' output, case when rate<80 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'301-l_p_actsess_info.log' DETAIL from 
(
select round(num_a_sess/value,2)*100 rate
  from v$parameter,
       (select count(*) num_a_sess from v$session where status='ACTIVE' and type='USER') 
 where name='cpu_count'
)
;
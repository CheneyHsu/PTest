select '#202-Undo Tablespace Usage(>50%): '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'202-l_s_undo_info.log' DETAIL from 
(
select * from
(
SELECT a.tsname,round(a.total_m,2) total_mb,
round(nvl(b.used_m,0),2) used_mb,
round(nvl((b.used_m/a.total_m)*100,0),2) used_percentage
from
(select t.tablespace_name tsname,sum(f.bytes)/1024/1024 total_m
from dba_tablespaces t,dba_data_files f
where t.tablespace_name=f.tablespace_name
and t.contents='UNDO'
group by t.tablespace_name) a,
(select tablespace_name tsname,sum(bytes)/1024/1024 used_m from dba_undo_extents
where status in ('ACTIVE')
group by tablespace_name
) b
where
a.tsname=b.tsname(+)
) where used_percentage>50
)
;
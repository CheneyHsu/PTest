set pagesize 999 linesize 131 feed 1 verify off trims off heading on
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss';

spool 001-l_a_inst_status.log
@@l_a_inst_status.sql
spool off

spool 101-l_a_dbfile_info.log
@@l_a_dbfile_info.sql
spool off

spool 102-l_a_redo_info.log
@@l_a_redo_info.sql
spool off

spool 103-l_a_invobj_info.log
@@l_a_invobj_info.sql
spool off

spool 104-l_a_invind_info.log
@@l_a_invind_info.sql
spool off

spool 201-l_s_tbs_info.log
@@l_s_tbs_info.sql
spool off

spool 202-l_s_undo_info.log
@@l_s_undo_info.sql
spool off

spool 203-l_s_temp_info.log
@@l_s_temp_info.sql
spool off

spool 301-l_p_actsess_info.log
@@l_p_actsess_info.sql
spool off

spool 302-l_p_actsess_info.log
@@l_p_actsess_info.sql
spool off

spool 303-l_p_actsess_info.log
@@l_p_actsess_info.sql
spool off

spool 304-l_p_lock_info.log
@@l_p_lock_info.sql
spool off

spool 305-l_p_actsess_info.log
@@l_p_actsess_info.sql
spool off

spool 306-l_p_sgaresize_info.log
@@l_p_sgaresize_info.sql
spool off

exit


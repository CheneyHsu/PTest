select '#201-Data Tablespace Usage(>80%): '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'201-l_s_tbs_info.log' DETAIL from 
(
select a.tsname,round(a.total_m,2) total_mb,
round(nvl(a.total_m-b.free_m,0),2) used_mb,
100-round(nvl((b.free_m/a.total_m)*100,0),2) used_percentage from
(select tablespace_name tsname,sum(bytes)/1024/1024 total_m from dba_data_files group by tablespace_name) a,
(select tablespace_name tsname,sum(bytes)/1024/1024 free_m from dba_free_space group by tablespace_name) b,
dba_tablespaces c
where a.tsname=b.tsname(+)
and a.tsname=c.tablespace_name
and c.contents not in ('UNDO','TEMPORARY')
and 100-round(nvl((b.free_m/a.total_m)*100,0),2)>80
)
;
select '#103-Invalid Objects: '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'103-l_a_invobj_info.log' DETAIL from 
(
select owner,
       object_type,
       object_name,
       status,
       to_char(created,'yyyymmdd hh24:mi:ss') created_time,
       to_char(last_ddl_time, 'yyyymmdd hh24:mi:ss') last_ddl_time
  from dba_objects
 where  status = 'INVALID' and owner not in ('PERFSTAT','DBSNMP','OUTLN','DRSYS','WKSYS','TSMSYS','SYSMAN_MDS','WMSYS','ORDSYS','MDSYS','CTXSYS','XDB','SQLTXPLAIN','SYSMAN','AURORA$JIS$UTILITY$','OSE$HTTP$ADMIN')
and last_ddl_time>sysdate-1
union all
select 
o.owner,
o.object_type,
o.object_name,
o.status, 
to_char(o.created,'yyyymmdd hh24:mi:ss') created_time,
to_char(rd.last_ddl_time, 'yyyymmdd hh24:mi:ss') last_ddl_time
from dba_objects o,dba_dependencies p,dba_objects rd
where p.name =o.object_name 
and p.owner=o.owner
and p.type=o.object_type
and p.referenced_name=rd.object_name
and p.referenced_owner=rd.owner
and p.referenced_type=rd.object_type
and o.status = 'INVALID' and o.owner not in ('PERFSTAT','DBSNMP','OUTLN','DRSYS','WKSYS','TSMSYS','SYSMAN_MDS','WMSYS','ORDSYS','MDSYS','CTXSYS','XDB','SQLTXPLAIN','SYSMAN','AURORA$JIS$UTILITY$','OSE$HTTP$ADMIN')
and o.last_ddl_time<=sysdate-1
and rd.last_ddl_time>sysdate-1
)
;
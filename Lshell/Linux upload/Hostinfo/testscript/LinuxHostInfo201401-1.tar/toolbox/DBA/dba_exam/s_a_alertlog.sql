prompt ======================================== 
prompt #401-Latest errors from &alert_log:
prompt   
host tail -100 &alert_log |grep "ORA-"
prompt ========================================
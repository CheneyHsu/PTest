#!/bin/sh
clear
filepath=$(cd "$(dirname "$0")";pwd)
seq(){ if [ "$1" = "-f" ];then
        function seq {
        i=$3
        while [ "$i" -le "$4" ]
        do
                echo "$i"
                i=$(($i+1))
        done
        }
        printf "$2\n" `seq $1 $2 $3 $4`
else
        function seq {
        i=$1
        while [ "$i" -le "$2" ]
        do
                echo "$i"
                i=$(($i+1))
        done
}
        seq $1 $2
fi
}

function set_env
{
orauser=oracle
oradir=`cat /etc/passwd |grep $orauser|awk -F ':' '{print $6}'`
if [ -f $oradir/.bash_profile ];then
    . $oradir/.bash_profile > /dev/null 2>&1
fi

if [ -f $oradir/.profile ];then
    . $oradir/.profile  > /dev/null 2>&1
fi
}

choose_sid(){
inst_num=`ps -ef|grep ora_|grep -v grep|awk -F '_' '{print $NF}'|sort|uniq|wc -l`
if [ "$inst_num" -eq 0 ];then
  echo "WARNING!!The instance is not running!!!"
else
  clear
     sh $filepath/list.sh
         >/tmp/.choice.sh        
           echo "OUT=1"  >>/tmp/.choice.sh 
           echo "while [ "\$OUT" -eq 1 ]"  >>/tmp/.choice.sh 
           echo "do" >>/tmp/.choice.sh 
           echo "echo "enter your choice:"" >>/tmp/.choice.sh 
           echo "read num">>/tmp/.choice.sh 
           echo "case "\$num" in" >>/tmp/.choice.sh 
             for i in `seq 1 $inst_num`
              do 
                echo "ps -ef|grep ora_|grep -v grep|awk -F '_' '{print \$NF}'|sort|uniq|awk 'NR==${i}{print}'" >/tmp/.tmp.sh
                j=`sh /tmp/.tmp.sh`
                 set_env
                 echo  "${i}) clear ; export ORACLE_SID=$j ; sh $filepath/run.sh ; exit ;;" >> /tmp/.choice.sh 
              done
           echo "q|Q|quit|exit) OUT=0 ;;" >>/tmp/.choice.sh 
           echo "*) clear ; sh $filepath/list.sh ;;" >>/tmp/.choice.sh 
           echo "esac" >>/tmp/.choice.sh
           echo "done" >>/tmp/.choice.sh 
     
         sh /tmp/.choice.sh 
fi
}

choose_sid

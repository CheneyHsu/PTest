select '#101-Invalid Data Files: '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'101-l_a_dbfile_info.log' DETAIL from 
(
select ts#,tablespace_name,file_id,file_name,df.bytes/1024/1024 size_mb,
       cf.creation_time,cf.checkpoint_time,cf.unrecoverable_time,
       cf.status header_status,df.status file_status,cf.enabled
  from v$datafile cf,dba_data_files df
 where df.file_id=cf.file#(+)
union all
select ts#,tablespace_name,file_id,file_name,df.bytes/1024/1024 size_mb,
       cf.creation_time,null checkpoint_time,null unrecoverable_time,
       cf.status header_status,df.status file_status,cf.enabled
  from v$tempfile cf,dba_temp_files df
 where df.file_id=cf.file#(+)
) where header_status not in ('ONLINE','SYSTEM') or file_status not in ('AVAILABLE','ONLINE')
;
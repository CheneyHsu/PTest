
select tablespace_name,total_blocks,used_blocks,free_blocks 
from v$sort_segment
;

select distinct u.tablespace,u.username,u.contents,u.segtype,
u.blocks,u.sql_id sort_sqlid, s.sid,s.program,s.machine,s.status,
s.event,s.state,s.last_call_et,s.sql_id,l.sql_text 
from v$sort_usage u, v$session s,v$sqlstats l
where u.session_addr=s.saddr
and s.sql_id=l.sql_id(+)
order by blocks desc;
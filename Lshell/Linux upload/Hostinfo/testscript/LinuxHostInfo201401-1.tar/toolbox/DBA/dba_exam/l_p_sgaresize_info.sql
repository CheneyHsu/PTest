

select component,oper_type,oper_mode,initial_size,target_size,status,start_time,end_time
from v$sga_resize_ops
order by start_time;

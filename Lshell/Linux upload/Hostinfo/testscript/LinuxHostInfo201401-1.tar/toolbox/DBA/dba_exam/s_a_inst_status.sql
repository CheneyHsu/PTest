select '#001-Instance Status: '||status output, case status when 'OPEN' then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'001-l_a_inst_status.log' DETAIL
  from v$instance
;
select '#303-Active Session Latch Rate: '||rate||'%' output, case when rate<30 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'303-l_p_actsess_info.log' DETAIL from 
(
select round(num_a_sess/value,2)*100 rate
  from v$parameter,
       (select count(*) num_a_sess from v$session where status='ACTIVE' and type='USER' and state='WAITING' and event like 'latch%') 
 where name='cpu_count'
)
;

select di.owner,di.index_name,null partition_name, null subpartition_name,di.status,created created_time,last_ddl_time
from dba_indexes di,dba_objects do
where di.owner=do.owner and di.index_name=do.object_name and do.object_type='INDEX' and di.status not in ('VALID','N/A')
union all
select dp.index_owner,dp.index_name,dp.partition_name,null subpartition_name,dp.status,created created_time,last_ddl_time
from dba_ind_partitions dp,dba_objects do
where dp.index_owner=do.owner and dp.index_name=do.object_name and do.object_type='INDEX PARTITION' and dp.status not in ('USABLE','N/A')
union all
select ds.index_owner,ds.index_name,ds.partition_name,ds.subpartition_name,ds.status,created created_time,last_ddl_time
from dba_ind_subpartitions ds ,dba_objects do
where ds.index_owner=do.owner and ds.index_name=do.object_name and do.object_type='INDEX PARTITION' and ds.status not in ('USABLE')
order by 1,2,3,4
;
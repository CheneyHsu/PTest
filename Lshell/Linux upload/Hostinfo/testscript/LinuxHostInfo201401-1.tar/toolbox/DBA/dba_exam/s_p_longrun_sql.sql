select '#305-Long Running(>10mins) SQLs: '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'305-l_p_actsess_info.log' DETAIL
from v$session where status='ACTIVE' and type='USER' and last_call_et>600
;
select '#203-Temp Tablespace Usage(>80%): '||count(*) output, case count(*) when 0 then 'OK' else 'WARNING' end RESULT, '&&log_dir'||'203-l_s_temp_info.log' DETAIL from 
(
select s.tablespace_name tsname,
f.total_m total_mb,
round(s.used_blocks*t.block_size/1024/1024,2) used_mb,
round((round(s.used_blocks*t.block_size/1024/1024,2)/f.total_m)*100,2) used_percentage
from v$sort_segment s,dba_tablespaces t,(select tablespace_name tsname,sum(bytes)/1024/1024 total_m from dba_temp_files group by tablespace_name) f
where s.tablespace_name=t.tablespace_name
and t.tablespace_name=f.tsname
and t.contents in ( 'TEMPORARY')
and round((round(s.used_blocks*t.block_size/1024/1024,2)/f.total_m)*100,2)>80
)
;
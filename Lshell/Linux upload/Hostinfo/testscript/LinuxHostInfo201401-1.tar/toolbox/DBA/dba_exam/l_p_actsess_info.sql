

select /* with sql 10g */ 
p.spid,s.sid,s.username,s.status,s.last_call_et,
s.program,s.last_call_et,
s.event,s.p1,s.p2,s.p3,
s.state,s.wait_time,s.seconds_in_wait wait_sec,
l.sql_text,l.sql_id,s.SQL_CHILD_NUMBER
from v$session s, v$process p,v$sqlstats l
where s.type='USER'and 
p.addr=s.paddr
and s.status='ACTIVE'
and s.sql_id=l.sql_id(+)
and event not in ('PL/SQL lock timer')
order by s.last_call_et;

#!/bin/sh
seq(){ if [ "$1" = "-f" ];then
        function seq {
        i=$3
        while [ "$i" -le "$4" ]
        do
                echo "$i"
                i=$(($i+1))
        done
        }
        printf "$2\n" `seq $1 $2 $3 $4`
else
        function seq {
        i=$1
        while [ "$i" -le "$2" ]
        do
                echo "$i"
                i=$(($i+1))
        done
}
        seq $1 $2
fi
}


inst_num=`ps -ef|grep ora_|grep -v grep|awk -F '_' '{print $NF}'|sort|uniq|wc -l` 
echo "Choose the script !!" 
    for i in `seq 1 $inst_num`
         do 
            echo "ps -ef|grep ora_|grep -v grep|awk -F '_' '{print \$NF}'|sort|uniq|awk 'NR==${i}{print}'" >/tmp/.tmp.sh 
            j=`sh /tmp/.tmp.sh` 
            echo "${i})    $j" 
          done 
         echo "q)    quit" 


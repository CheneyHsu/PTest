
select * from v$database;
select * from v$instance;


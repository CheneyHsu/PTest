#!/bin/sh
shelldir=/home/sysadmin/toolbox/midware/conf/tux/shell
cfgfile=$shelldir/mon.cfg
nfservfile=$shelldir/server.cfg
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
chose=`echo $1|sed 's/-//g'`
if [ -e $cfgfile ]
    then
        tmpdir=`cat ${cfgfile}|grep tmpdir|awk -F"=" '{print $2}'`
        logdir=`cat ${cfgfile}|grep logdir|awk -F"=" '{print $2}'`
        errdir=`cat ${cfgfile}|grep errdir|awk -F"=" '{print $2}'`
        appname=`cat ${cfgfile}|grep appname|awk -F"=" '{print $2}'`
        warnquenum=`cat ${cfgfile}|grep warnquenum|awk -F"=" '{print $2}'`
        realquenum=`cat ${cfgfile}|grep realquenum|awk -F"=" '{print $2}'`
        warnpsrnum=`cat ${cfgfile}|grep warnpsrnum|awk -F"=" '{print $2}'`
    else
        echo "Can't find mon.cfg file"
        exit $STATE_WARNING
fi
#config the queue warning value when the request number over this value will given warning information
#warnquenum=10
#config the queue send warning when the number over this value
#realquenum=20
#get current username
curusr=`whoami`
#config the user who you want to run this shell 
if [ "$curusr" = "root" ]
    then
        appusr=`cat ${cfgfile}|grep appusr|awk -F"=" '{print $2}'`
    else
        appusr=$curusr
fi
#define dir val info
#tmpdir=/home/ecisrv/ecimon/tmp
#logdir=/home/ecisrv/ecimon/log
#errdir=/home/ecisrv/ecimon/err
#init tmp file and given visit authority
cat /dev/null>${tmpdir}/infostmp_${curusr}_${chose}
chmod 666 ${tmpdir}/infostmp_${curusr}_${chose}
cat /dev/null>${tmpdir}/tmconftmp_${curusr}_${chose}
chmod 666 ${tmpdir}/tmconftmp_${curusr}_${chose}
cat /dev/null>${tmpdir}/dmconftmp_${curusr}_${chose}
chmod 666 ${tmpdir}/dmconftmp_${curusr}_${chose}
cat /dev/null>${tmpdir}/date_${curusr}_${chose}
chmod 666 ${tmpdir}/date_${curusr}_${chose}
#define appname
#appname=ECIF
#define date file
date +"%Y%m%d">${tmpdir}/date_${curusr}_${chose}
#define date val
sysdate=`cat ${tmpdir}/date_${curusr}_${chose}`
#function
#check the $appusr env can running tmadmin command
envchkinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr}_${chose} 2>/dev/null <<!
bbs
!
}
#check the root env can running tmadmin command
envchkinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr}_${chose} 2>/dev/null <<!
bbs
!
}
#check the $appusr env can running dmadmin command
dmenvchkinfo()
{
dmadmin -r 1>${tmpdir}/infostmp_${curusr}_${chose} 2>/dev/null <<!
!
}
#check the root env can running dmadmin command
dmenvchkinfo_2()
{
su - $appusr -c dmadmin -r 1>${tmpdir}/infostmp_${curusr}_${chose} 2>/dev/null <<!
!
}
#get tmadmin console psc command information by $appusr
pscinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
psc
!
}
#get tmadmin console psc command information by root
pscinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
psc
!
}
#get tmadmin console pclt command information by $appusr
pcltinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
pclt
!
}
#get tmadmin console pclt command information by root
pcltinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
pclt
!
}
#get tmadmin console bbs command information by $appusr
bbsinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
bbs
!
}
#get tmadmin console bbs command information by root
bbsinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
bbs
!
}
#get tmadmin console pq command information by $appusr
pqinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
pq
!
}
#get tmadmin console pq command information by root
pqinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
pq
!
}
#get tmadmin console pq command information use queuetmp by $appusr
pqqinfo()
{
tmadmin -r 1>${tmpdir}/infosquetmp_${curusr} 2>/dev/null <<!
pq
!
}
#get tmadmin console pq command information use queuetmp by root
pqqinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infosquetmp_${curusr} 2>/dev/null <<!
pq
!
}
#get tmadmin console psr command information by $appusr
psrinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
psr
!
}
#get tmadmin console psr command information by root
psrinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_${curusr} 2>/dev/null <<!
psr
!
}
#get tmadmin console psr command detail information by $appusr
psrdinfo()
{
tmadmin -r 1>${tmpdir}/infostmp_detail_${curusr} 2>/dev/null <<!
v
psr
!
}
#get tmadmin console psr command detail information by root
psrdinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infostmp_detail_${curusr} 2>/dev/null <<!
v
psr
!
}
#get mp model tmadmin console psr command information by $appusr
mppsrinfo()
{
tmadmin -r 1>${tmpdir}/infoservtmp_${curusr} 2>/dev/null <<!
default -m $site
psr
!
}
#get mp model tmadmin console psr command information by root
mppsrinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infoservtmp_${curusr} 2>/dev/null <<!
default -m $site
psr
!
}
#get tmadmin console psr command information use servertmp by $appusr
psrsinfo()
{
tmadmin -r 1>${tmpdir}/infoservtmp_${curusr} 2>/dev/null <<!
psr
!
}
#get tmadmin console psr command information use servertmp by root
psrsinfo_2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/infoservtmp_${curusr} 2>/dev/null <<!
psr
!
}
#get dmadmin console $locdom domain connected information by $appusr
dminfo()
{
dmadmin -r 1>${tmpdir}/${locdom}tmp_${curusr} 2>/dev/null <<!
pd -d ${locdom}
!
}
#get dmadmin console $locdom domain connected information by root
dminfo_2()
{
su - $appusr -c dmadmin -r 1>${tmpdir}/${locdom}tmp_${curusr} 2>/dev/null <<!
pd -d ${locdom}
!
}
#get queue name information
getquename()
{
tmadmin -r 1>${tmpdir}/quename_tmp_${curusr} 2>/dev/null <<!
v
pq
!
}
#get queue name information by root
getquename2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/quename_tmp_${curusr} 2>/dev/null <<!
v
pq
!
}
#get queue name information by info
getquenameinfo()
{
tmadmin -r 1>${tmpdir}/quen_tmp_${curusr} 2>/dev/null <<!
v
pq
!
}
#get queue name information by rootinfo
getquenameinfo2()
{
su - $appusr -c tmadmin -r 1>${tmpdir}/quen_tmp_${curusr} 2>/dev/null <<!
v
pq
!
}
#when the shell parameter not right given the help information 
usage()
{
    echo "Usage:"
    echo "    check tuxedo navail service/busy queues/dead servers/custom num info"
    echo "    $Proname -i [-log]     "
    echo "    check tuxedo servers info"
    echo "    $Proname -s [-log]     "
    echo "    check tuxedo domaininfo "
    echo "    $Proname -d [-log]     "
    echo "    check tuxedo queueinfo "
    echo "    $Proname -q [-log]     "
}
#get the appusr env information by root
get_env()
{
su - $appusr -c env 1>${tmpdir}/infostmp_${curusr}_${chose} 2>/dev/null <<!
!
}
#init exit state value
#STATE_OK=0
#STATE_WARNING=1
#STATE_CRITICAL=2
#STATE_UNKNOWN=3
date +"%H:%M">${tmpdir}/mon_current_time
mon_time=`cat ${tmpdir}/mon_current_time`
if [ "$curusr" != "root" ]
    then
        if [ "$curusr" != "$appusr" ]
            then
                echo "WARN: CURUSR not equal $appusr or root.Please change usr or modify tmon.sh appusr parameter"
                echo ${mon_time}"|WARN: CURUSR not equal $appusr or root.Please change usr or modify tmon.sh appusr parameter">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                exit $STATE_WARNING
        fi
fi
#export tuxedo env information when the current user is root
if [ "$curusr" = "root" ]
    then
        get_env
        if [ $? -ne 0 ]
            then
                echo "WARN:Can't get appusr env information"
                echo "WARN:Can't get appusr env information">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                exit $STATE_WARNING
        fi
        for tmpvar in TUXDIR TUXCONFIG LIBPATH LD_LIBRARY_PATH BDMCONFIG SHLIB_PATH
        do
            tmpnum=`cat ${tmpdir}/infostmp_${curusr}_${chose}|grep ^$tmpvar"="|wc -l|sed 's/[[:space:]]//g'`
            if [ $tmpnum -eq 1 ]
                then
                    envtmp=`cat ${tmpdir}/infostmp_${curusr}_${chose}|grep ^$tmpvar"="`
                    export $envtmp
            fi
        done
        envtmp=`cat ${tmpdir}/infostmp_${curusr}_${chose}|grep ^PATH=`
        export $envtmp
fi
#check $TUXDIR whether exist if not exist given warning information
if [ ! -d $TUXDIR ]
    then
        echo "WARN:Not Find Dir TUXDIR "
        echo ${mon_time}"|WARN:Not Find Dir TUXDIR ">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
        exit $STATE_WARNING
fi
#check $TUXCONFIG whether exist if not exist given warning information
if [ ! -f $TUXCONFIG ]
    then
        echo "WARN:Not Find File TUXCONFIG"
        echo ${mon_time}"|WARN:Not Find File TUXCONFIG">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
        exit $STATE_WARNING
fi
#check busywarn_$curusr whether exist if not exist create file
busywarnname=${tmpdir}/busywarn_$curusr
if [ ! -f $busywarnname ]
    then
        cat /dev/null>${tmpdir}/busywarn_${curusr}
        chmod 666 ${tmpdir}/busywarn_${curusr}
fi
#check psrwarn_$curusr whether exist if not exist create file
psrwarnname=${tmpdir}/psrwarn_$curusr
if [ ! -f $psrwarnname ]
    then
        cat /dev/null>${tmpdir}/psrwarn_${curusr}
        chmod 666 ${tmpdir}/psrwarn_${curusr}
fi
#run function check env
if [ "$curusr" = "root" ]
    then
        envchkinfo_2
    else
        envchkinfo
fi
#if the function run failed given the warning information
if [ $? -ne 0 ]
    then
        echo "WARN:Can't Run Tmadmin Command Check TUXEDO IS Running "
        echo ${mon_time}"|WARN:Can't Run Tmadmin Command Check TUXEDO IS Running ">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
        exit $STATE_WARNING
fi
#when run tmadmin console bbs command if the result number equle zero given the warning information 
chknum=`cat ${tmpdir}/infostmp_${curusr}_${chose}|grep -v ">"|sed '/^$/d'|wc -l`
if [ $chknum -eq 0 ]
    then
        echo "WARN:CHECK TUXEDO IS BOOTING"
        echo ${mon_time}"|WARN:CHECK TUXEDO IS BOOTING">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
        exit $STATE_WARNING
fi
#get env $BDMCONFIG number
dmconfnum=`echo $BDMCONFIG|sed '/^$/d'|wc -l`
#if dmconfnum equle 1 check the BDMCONFIG file
if [ $dmconfnum -eq 1 ]
    then
        dmconf=`echo $BDMCONFIG`
        #check $BDMCONFIG file whether exist
        if [ -f $dmconf ]
            then
                if [ "$curusr" = "root" ]
                    then
                        dmenvchkinfo_2
                    else
                        dmenvchkinfo
                fi
                #the function give bad result then given warning information 
                if [ $? -ne 0 ]
                    then
                        echo "WARN:Can't Run Dmadmin Command CHECK TUXEDO IS Running"
                        echo ${mon_time}"|WARN:Can't Run Dmadmin Command CHECK TUXEDO IS Running">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                        exit $STATE_WARNING
                fi
        fi
fi
#check format when the parameter not equal -i or -d given the warning information
Proname=`basename $0`
if [ "$1" != "-s" -a "$1" != "-i" -a "$1" != "-d" -a "$1" != "-q" ]
    then
        usage
        if [ $? -ne 0 ]
            then
                echo "WARN:Check shell can run on the machine"
                echo ${mon_time}"|WARN:Check shell can run on the machine">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                exit $STATE_WARNING
        fi
fi
#unload tuxconfig if the user not equal root or $appusr given the warning information
if [ "$curusr" = "root" ]
    then
        su - $appusr -c tmunloadcf>${tmpdir}/tmconftmp_${curusr}_${chose}
    else
        if [ "$curusr" = "$appusr" ]
            then
                tmunloadcf>${tmpdir}/tmconftmp_${curusr}_${chose}
            else
                echo "WARN:Usr is not root or $appusr"
                echo ${mon_time}"|WARN:Usr is not root or $appusr">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                exit $STATE_WARNING
        fi
fi
#get env $BDMCONFIG number
dfnum=`echo $BDMCONFIG|sed '/^$/d'|wc -l`
if [ $dfnum -eq 1 ]
    then
        dffile=`echo $BDMCONFIG`
        #check BDMCONFIG file whether exist
        if [ -f $dffile ]
            then
                #unload dmconfig if the user not equal root or $appusr given the warning information
                if [ "$curusr" = "root" ]
                    then
                        su - $appusr -c dmunloadcf>${tmpdir}/dmconftmp_${curusr}_${chose}
                    else
                        if [ "$curusr" = "$appusr" ]
                            then
                                dmunloadcf>${tmpdir}/dmconftmp_${curusr}_${chose}
                            else
                                echo "WARN:Usr is not root or $appusr"
                                echo ${mon_time}"|WARN:Usr is not root or $appusr">>${errdir}/${appname}_otherr_${curusr}_${sysdate}
                                exit $STATE_WARNING  
                        fi
                fi
        fi  
fi
case $1  in
#when the parameter is -i get services/servers/queues information
    -i)
    cat /dev/null>${tmpdir}/infostmp_${curusr}
    chmod 666 ${tmpdir}/infostmp_${curusr}
    cat /dev/null>${tmpdir}/infos_${curusr}
    chmod 666 ${tmpdir}/infos_${curusr}
    cat /dev/null>${tmpdir}/svinoavail_${curusr}
    chmod 666 ${tmpdir}/svinoavail_${curusr}
    cat /dev/null>${tmpdir}/busyqntmp_${curusr}
    chmod 666 ${tmpdir}/busyqntmp_${curusr}
    cat /dev/null>${tmpdir}/busywarntmp_${curusr}
    chmod 666 ${tmpdir}/busywarntmp_${curusr}
    cat /dev/null>${tmpdir}/busyqname_${curusr}
    chmod 666 ${tmpdir}/busyqname_${curusr}
    cat /dev/null>${tmpdir}/deadserv_${curusr}
    chmod 666 ${tmpdir}/deadserv_${curusr}
    cat /dev/null>${tmpdir}/quen_tmp_${curusr}
    chmod 666 ${tmpdir}/quen_tmp_${curusr}
    cat /dev/null>${tmpdir}/quen_${curusr}
    chmod 666 ${tmpdir}/quen_${curusr}
    cat /dev/null>${tmpdir}/infos2_${curusr}
    chmod 666 ${tmpdir}/infos2_${curusr}
    cat /dev/null>${tmpdir}/psrwarntmp_${curusr}
    chmod 666 ${tmpdir}/psrwarntmp_${curusr}
    date +"%Y%m%d">${tmpdir}/date_infor_${curusr}
    infdate=`cat ${tmpdir}/date_infor_${curusr}`
    #get psc command information
    if [ "$curusr" = "root" ]
        then
            pscinfo_2
        else
            pscinfo
    fi
    #if the function run failed given the warning information
    if [ $? -eq 0 ]
        then
            bnum=`cat ${tmpdir}/infostmp_${curusr}|grep -n "> Service"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            bnum=`expr $bnum - 1`
            enum=`cat ${tmpdir}/infostmp_${curusr}|grep -v "Service"|grep -n ">"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            cat ${tmpdir}/infostmp_${curusr}|sed -n "$bnum,${enum}p">${tmpdir}/infos_${curusr}
            errornum=`cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"|wc -l`
            warnnum=`cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"|wc -l`
            if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                then
                    echo "WARN:TMADMIN CONSOLE RUN psc COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN psc COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
                    if [ $errornum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"
                    fi
                    if [ $warnnum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"
                    fi
                    exit $STATE_WARNING
            fi
            pscnanum=`cat ${tmpdir}/infos_${curusr}|sed '1,3d'|grep -v ">"|grep -v "AVAIL"|sed '/^$/d'|wc -l|sed 's/[[:space:]]//g'`
            if [ "$pscnanum" -ne 0 ]
                then
                    cat ${tmpdir}/infos_${curusr}|sed '1,3d'|grep -v ">"|sed '/^$/d'|grep -v "AVAIL">${tmpdir}/svinoavail_${curusr}
            fi
        else
            echo "WARN:TMADMIN CONSOLE RUN psc COMMAND FAILED"
            echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN psc COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
            exit $STATE_WARNING
    fi
    #get pclt command information
    if [ "$curusr" = "root" ]
        then
            pcltinfo_2
        else
            pcltinfo
    fi
    #if the function run failed given the warning information
    if [ $? -eq 0 ]
        then
            errornum=`cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"|wc -l`
            warnnum=`cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"|wc -l`
            if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                then
                    echo "WARN:TMADMIN CONSOLE RUN pclt COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pclt COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
                    if [ $errornum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"
                    fi
                    if [ $warnnum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"
                    fi
                    exit $STATE_WARNING
            fi
            bgtrans=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep "/"|awk '{print $6}'|awk -F"/" '{print ;c=c+$1} END {print c}'|grep -v "/"|sed 's/[[:space:]]//g'`
            custconnum=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep "/"|sed '1,2d'|wc -l|sed 's/[[:space:]]//g'`
            #comittrans=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep "/"|awk '{print $6}'|awk -F"/" '{print ;c=c+$2} END {print c}'|grep -v "/"|sed 's/[[:space:]]//g'`
            #rbacktrans=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep "/"|awk '{print $6}'|awk -F"/" '{print ;c=c+$3} END {print c}'|grep -v "/"|sed 's/[[:space:]]//g'`
            #clconnum=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|wc -l|sed 's/[[:space:]]//g'`
        else
            echo "WARN:TMADMIN CONSOLE RUN pclt COMMAND FAILED"
            echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pclt COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
            exit $STATE_WARNING
    fi
    #get bbs command information
    if [ "$curusr" = "root" ]
        then
            bbsinfo_2
        else
            bbsinfo
    fi
    #if the function run failed given the warning information
    if [ $? -eq 0 ]
        then
            errornum=`cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"|wc -l`
            warnnum=`cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"|wc -l`
            if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                then
                    echo "WARN:TMADMIN CONSOLE RUN bbs COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN bbs COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
                    if [ $errornum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"
                    fi
                    if [ $warnnum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"
                    fi
                    exit $STATE_WARNING
            fi
            #cnserver=`cat ${tmpdir}/infostmp_${curusr}|grep "servers"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'`
            cnservices=`cat ${tmpdir}/infostmp_${curusr}|grep "services"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'`
            #cnqueues=`cat ${tmpdir}/infostmp_${curusr}|grep "queues"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'`
            #cngroups=`cat ${tmpdir}/infostmp_${curusr}|grep "groups"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'`
            #cninterfaces=`cat ${tmpdir}/infostmp_${curusr}|grep "interfaces"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'`
        else
            echo "WARN:TMADMIN CONSOLE RUN bbs COMMAND FAILED"
            echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN bbs COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
            exit $STATE_WARNING
    fi
    #get pq command information
    if [ "$curusr" = "root" ]
        then
            pqinfo_2
            getquenameinfo2
        else
            pqinfo
            getquenameinfo
    fi
    #if the function run failed given the warning information
    if [ $? -eq 0 ]
        then
            bnum=`cat ${tmpdir}/infostmp_${curusr}|grep -n "> Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            bnum=`expr $bnum - 1`
            enum=`cat ${tmpdir}/infostmp_${curusr}|grep -n ">"|grep -v "Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            enum=`expr $enum + 1`
            cat ${tmpdir}/infostmp_${curusr}|sed -n "$bnum,${enum}p">${tmpdir}/infos_${curusr}
            cat ${tmpdir}/quen_tmp_${curusr}|grep "Queue Name"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'>${tmpdir}/quen_${curusr}
            cat ${tmpdir}/infos_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'>${tmpdir}/infos2_${curusr}
            paste ${tmpdir}/infos2_${curusr} ${tmpdir}/quen_${curusr}>${tmpdir}/infos_${curusr}
            errornum=`cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"|wc -l`
            warnnum=`cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"|wc -l`
            if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                then
                    echo "WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
                    if [ $errornum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"
                    fi
                    if [ $warnnum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"
                    fi
                    exit $STATE_WARNING
            fi
            qlen=`cat ${tmpdir}/infos_${curusr}|sed '$d'|grep -v "GWTDOMAIN"|awk '($6!="-") {print ;a=a+$6;} END {print a}'|sed -n '/^[0-9]/p'|sed 's/[[:space:]]//g'`
            trqnum=`cat ${tmpdir}/infos_${curusr}|sed '$d'|grep -v "GWTDOMAIN"|awk ' {print ;a=a+$5;} END {print a}'|sed -n '/^[0-9]/p'|sed 's/[[:space:]]//g'`
            cat ${tmpdir}/infos_${curusr}|sed '$d'|grep -v "GWTDOMAIN"|awk -v a=$warnquenum '($5>a) {print $1,$2,$3,$5,$7}'>${tmpdir}/busyqntmp_${curusr}
            cat ${tmpdir}/infos_${curusr}|sed '$d'|grep -v "GWTDOMAIN"|awk -v a=$warnquenum '($5<0) {print $1,$2,$3,$5,$7}'>>${tmpdir}/busyqntmp_${curusr}
            busyqunum=`wc -l ${tmpdir}/busyqntmp_${curusr}|sed '/^$/d'|awk '{print $1}'|sed 's/[[:space:]]//g'`
            awk '{print $2,$5}' ${tmpdir}/busyqntmp_${curusr}>${tmpdir}/busyqname_${curusr}
            if [ $busyqunum -ne 0 ]
                then
                m=1
                while [ $m -le $busyqunum ]
                do
                    quename=`awk -v a=$m 'NR==a {print $1}' ${tmpdir}/busyqname_${curusr}`
                    mahname=`awk -v a=$m 'NR==a {print $2}' ${tmpdir}/busyqname_${curusr}`
                    obqunum=`cat ${tmpdir}/busywarn_${curusr}|awk -v  a=$quename '($2 ~ a) {print $0}'|grep ${mahname}|wc -l|sed 's/[[:space:]]//g`
                    if [ $obqunum -ne 1 ]
                        then
                            
                            awk -v a=$m 'NR==a {print $1,$2,$4,$5,1}' ${tmpdir}/busyqntmp_${curusr}>>${tmpdir}/busywarntmp_${curusr}
                        else
                            
                            cat ${tmpdir}/busywarn_${curusr}|awk -v  a=$quename '($2 ~ a) {print $0}'|grep $mahname|awk '{print $1,$2,$3,$4,$5+1}'>>${tmpdir}/busywarntmp_${curusr}
                    fi
                    m=`expr $m + 1`
                done
                cat ${tmpdir}/busywarntmp_${curusr}|grep -v "GWTDOMAIN" > ${tmpdir}/busywarn_${curusr}   
                else
                    cat /dev/null>${tmpdir}/busywarn_${curusr}          
            fi
        else
            echo "WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED"
            echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
            exit $STATE_WARNING
    fi
    echo "queue/services info               "
    #get config model information
    model=`cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "MODEL"|awk '{print $2}'|sed 's/[[:space:]]//g'`
    #get services avail and not avail information
    availnum=`expr $cnservices - $pscnanum`
    notavailnum=`expr $cnservices - $availnum`
    #SHM model get psr command information
    if [ "$model" = "SHM" ]
        then
            if [ "$curusr" = "root" ]
                then
                    psrinfo_2
                else
                    psrinfo
            fi
            if [ $? -eq 0 ]
                then
                    errornum=`cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"|wc -l`
                    warnnum=`cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"|wc -l`
                    if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                        then
                            echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                            if [ $errornum -ne 0 ]
                                then
                                    cat ${tmpdir}/infostmp_${curusr}|grep "ERROR:"
                            fi
                            if [ $warnnum -ne 0 ]
                                then
                                    cat ${tmpdir}/infostmp_${curusr}|grep "WARN:"
                            fi
                            exit $STATE_WARNING
                    fi
                    idlenum=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|grep IDLE|wc -l|sed 's/[[:space:]]//g'`
                    deadnum=`cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|grep DEAD|awk '$8=="DEAD" {print $8}'|wc -l|sed 's/[[:space:]]//g'`
                    if [ $deadnum -ne 0 ]
                        then
                            cat ${tmpdir}/infostmp_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|grep DEAD|awk '$8=="DEAD" {print $1,$2,$8}'>${tmpdir}/deadserv_${curusr}
                    fi
                    if [ "$curusr" = "root" ]
                        then
                            psrdinfo_2
                        else
                            psrdinfo
                    fi
                    cat ${tmpdir}/infostmp_detail_${curusr}|grep "Group ID"|sed "s/>//g"|awk '{print $3}'|sed 's/,//g'|sed 's/[[:space:]]//g'>${tmpdir}/infostmp_group_${curusr}
                    cat ${tmpdir}/infostmp_detail_${curusr}|grep "Queue Name"|sed "s/>//g"|awk '{print $3}'|sed 's/[[:space:]]//g'>${tmpdir}/infostmp_quename_${curusr}
                    cat ${tmpdir}/infostmp_detail_${curusr}|grep "Prog Name"|sed "s/\/*[a-zA-Z0-9_-]*\///g"|awk '{print $3}'|sed 's/[[:space:]]//g'>${tmpdir}/infostmp_progname_${curusr}
                    bnum=`cat ${tmpdir}/infostmp_${curusr}|grep -n "> Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                    enum=`cat ${tmpdir}/infostmp_${curusr}|grep -n ">"|grep -v "Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                    cat ${tmpdir}/infostmp_${curusr}|sed -n "$bnum,${enum}p"|grep -v ">"|sed '$d'>${tmpdir}/infostmp_psr_${curusr}
                    paste ${tmpdir}/infostmp_quename_${curusr} ${tmpdir}/infostmp_group_${curusr} ${tmpdir}/infostmp_progname_${curusr} ${tmpdir}/infostmp_psr_${curusr}>${tmpdir}/infostmp_psr_tmp_${curusr}
                    cat ${tmpdir}/infostmp_psr_tmp_${curusr}|grep -v "IDLE"|grep -v "GWTDOMAIN"|sed 's/(//g'|sed 's/)//g'|awk -v a=BUSY '{b=($10 ~ /^$/) ? a : $10;printf "%s %s-%s-%ld %s\n",$3,$1,$2,$7,b}'>${tmpdir}/psrqntmp_${curusr}
                    psrqunum=`wc -l ${tmpdir}/psrqntmp_${curusr}|awk '{print $1}'|sed 's/[[:space:]]//g'`
                    awk '{print $2}' ${tmpdir}/psrqntmp_${curusr}>${tmpdir}/psrqname_${curusr}
                    if [ $psrqunum -ne 0 ]
                        then
                        n=1
                        while [ $n -le $psrqunum ]
                        do
                            psrname=`awk -v a=$n 'NR==a {print $1}' ${tmpdir}/psrqname_${curusr}`
                            obqunum=`cat ${tmpdir}/psrwarn_${curusr}|awk -v  a=$psrname '($2 ~ a) {print $0}'|wc -l|sed 's/[[:space:]]//g`
                            if [ $obqunum -ne 1 ]
                                then
                                    awk -v a=$n 'NR==a {print $1,$2,$3,1}' ${tmpdir}/psrqntmp_${curusr}>>${tmpdir}/psrwarntmp_${curusr}
                                else
                                    cat ${tmpdir}/psrwarn_${curusr}|awk -v  a=$psrname '($2 ~ a) {print $0}'|awk '{print $1,$2,$3,$4+1}'>>${tmpdir}/psrwarntmp_${curusr}
                            fi
                            n=`expr $n + 1`
                        done
                        cat ${tmpdir}/psrwarntmp_${curusr}|grep -v "GWTDOMAIN" > ${tmpdir}/psrwarn_${curusr}
                        else
                            cat /dev/null>${tmpdir}/psrwarn_${curusr}
                    fi
                    nfservnum=`cat ${nfservfile}|wc -l|sed 's/[[:space:]]//g'`
                    if [ $nfservnum -ne 0 ]
                        then
                        q=1
                        while [ $q -le $nfservnum ]
                        do
                            servname=`awk -v a=$q 'NR==a {print $1}' ${nfservfile}`
                            cat ${tmpdir}/psrwarn_${curusr}|grep -v ${servname}>${tmpdir}/psrwarntmp_${curusr}
                            mv ${tmpdir}/psrwarntmp_${curusr} ${tmpdir}/psrwarn_${curusr}
                            q=`expr $q + 1`
                        done
                    fi
                else
                    echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${infdate}
                    exit $STATE_WARNING
            fi
            confnum=`cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "MIN="|awk '{print $4}'|awk -F"=" '{print ;d=d+$2} END {print d+1}'|grep -v "MIN"|sed 's/[[:space:]]//g'`
        else
            #MP model get psr command information
            confnum=`cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "MIN="|awk '{print $4}'|awk -F"=" '{print ;d=d+$2} END {print d+4}'|grep -v "MIN"|sed 's/[[:space:]]//g'`
    fi
    #get config file group numbers
    #gconfnum=`cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "GRPNO"|wc -l|sed 's/[[:space:]]//g'`
    if [ "$model" = "SHM" ]
        then
            #show the shm model monitor information
            echo "Svc_No_Avail   Svr_Dead   Que_Req   Busy_Que   Cus_Con"
            echo "------------   --------   -------   --------   -------"
            echo $bgtrans|awk -v a=$notavailnum \
            -v d=$trqnum -v e=$busyqunum -v f=$deadnum -v b=$custconnum\
            '{printf "%s              %-11s%-5s     %-11s%-7s\n",a,f,d,e,b}'
            #write log file
            if [ "$2" = "-log" ]
                then      
                    date +"%H:%M">${tmpdir}/queue_current_time
                    queue_time=`cat ${tmpdir}/queue_current_time`
                    echo $bgtrans|awk -v a=$notavailnum \
                    -v d=$trqnum -v e=$busyqunum -v f=$deadnum -v g=$queue_time -v b=$custconnum\
                    '{printf "%s|%s|%s|%s|%s|%s\n",g,a,f,d,e,b}'>>${logdir}/${appname}_queue_${curusr}_${infdate}
           fi
        else
            #show the mp model monitor information
            echo "Svc_No_Avail   Que_Req   Busy_Que   Cus_Con"
            echo "------------   -------   --------   -------"
            echo $bgtrans|awk -v a=$notavailnum \
            -v d=$trqnum -v e=$busyqunum  -v c=$custconnum \
            '{printf "%s              %-10s%-11s%-7s\n",a,d,e,c}'
            #write log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/queue_current_time
                    queue_time=`cat ${tmpdir}/queue_current_time`
                    echo $bgtrans|awk -v a=$notavailnum \
                    -v d=$trqnum -v e=$busyqunum -v f=$queue_current_time -v b=$custconnum \
                    '{printf "%s|%s|%s|%s|%s\n",f,a,d,e,b}'>>${logdir}/${appname}_queue_${curusr}_${infdate}
            fi
    fi
    ierrfile=${errdir}/${appname}_ierr_${curusr}_${infdate}
    if [ -e ${ierrfile} ]
        then
            ierrfile=${errdir}/${appname}_ierr_${curusr}_${infdate}
        else
            cat /dev/null>${errdir}/${appname}_ierr_${curusr}_${infdate}
    fi
    if [ $notavailnum -ne 0 ]
        then
            date +"%H:%M">${tmpdir}/queue_current_time
            queue_time=`cat ${tmpdir}/queue_current_time`
            echo "">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo ${queue_time}" WARN:NO AVAIL SERVICES TOP 10">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "Service Name   Prog Name   Machine    Status">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "------------   ---------   -------    ------">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            cat ${tmpdir}/svinoavail_${curusr}|awk '{printf "%-15s%-12s%-11s%-10s\n",$1,$3,$6,$8}'|head -n 10>>${errdir}/${appname}_ierr_${curusr}_${infdate}
            #write err log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/queue_current_time
                    queue_time=`cat ${tmpdir}/queue_current_time`
                    cat ${tmpdir}/svinoavail_${curusr}|awk -v a=$queue_time '{printf "%s|%s|%s|%s|%s\n",a,$1,$3,$6,$8}'>>${errdir}/${appname}_serviceerr_${curusr}_${infdate}
            fi
    fi
    quewarngnum=`cat ${tmpdir}/busywarn_${curusr}|awk -v a=$realquenum '($5>a) {print $1,$2,$3,$4,$5}'|wc -l|sed  's/[[:space:]]//g'`
    if [ $quewarngnum -ne 0 ]
        then
            date +"%H:%M">${tmpdir}/queue_current_time
            queue_time=`cat ${tmpdir}/queue_current_time`
            echo "">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo ${queue_time}" WARN:BUSY QUEUE INFO">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "Prog Name      Queue Name               Queued    Machine   Number    ">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "---------      --------------------     ------    -------   ------    " >>${errdir}/${appname}_ierr_${curusr}_${infdate}
            cat ${tmpdir}/busywarn_${curusr}|awk -v a=$realquenum '($5>a) {printf "%-15s%-25s%-10s%-10s%-10s\n",$1,$2,$3,$4,$5}'|head -n 10>>${errdir}/${appname}_ierr_${curusr}_${infdate}
            #write err log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/queue_current_time
                    queue_time=`cat ${tmpdir}/queue_current_time`
                    cat ${tmpdir}/busywarn_${curusr}|awk -v a=$realquenum -v b=$queue_time '($5>a) {printf "%s|%s|%s|%s|%s|%s\n",b,$1,$2,$3,$4,$5}'>>${errdir}/${appname}_queueerr_${curusr}_${infdate}
            fi
    fi
    deadsernum=`cat ${tmpdir}/deadserv_${curusr}|wc -l|sed  's/[[:space:]]//g'`
    if [ $deadsernum -ne 0 ]
        then
            date +"%H:%M">${tmpdir}/queue_current_time
            queue_time=`cat ${tmpdir}/queue_current_time`
            echo "">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo ${queue_time}" WARN:DEAD SERVERS INFO">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "Prog Name      Queue Name     Status">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "---------      ----------     ------">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            cat ${tmpdir}/deadserv_${curusr}|awk '{printf "%-15s%-15s%-s\n",$1,$2,$3}'|head -n 10>>${errdir}/${appname}_ierr_${curusr}_${infdate}
            #write err log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/queue_current_time
                    queue_time=`cat ${tmpdir}/queue_current_time`
                    cat ${tmpdir}/deadserv_${curusr}|awk -v a=$queue_time '{printf "%s|%s|%s|%s\n",a,$1,$2,$3}'>>${errdir}/${appname}_servererr_${curusr}_${infdate}
            fi
    fi
    psrwarnnum=`cat ${tmpdir}/psrwarn_${curusr}|awk -v a=${warnpsrnum} '($4>a) {print $1,$2,$3,$4}'|wc -l|sed  's/[[:space:]]//g'`
    if [ $psrwarnnum -ne 0 ]
        then
            date +"%H:%M">${tmpdir}/psr_current_time
            psr_time=`cat ${tmpdir}/psr_current_time`
            echo "">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo ${psr_time}" WARN:PSR ALWAYS BUSY INFO">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "Prog Name           QN-GI-PI                      STATUS         CNum">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            echo "---------           --------                      ------         ----">>${errdir}/${appname}_ierr_${curusr}_${infdate}
            cat ${tmpdir}/psrwarn_${curusr}|awk -v a=$warnpsrnum '($4>a) {printf "%-20s%-30s%-15s%-10ld\n",$1,$2,$3,$4}'>>${errdir}/${appname}_ierr_${curusr}_${infdate}
            #write err log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/psr_current_time
                    psr_time=`cat ${tmpdir}/psr_current_time`
                    cat ${tmpdir}/psrwarn_${curusr}|awk -v a=$warnpsrnum -v b=$psr_time '($4>a) {printf "%s|%s|%s|%s|%ld\n",b,$1,$2,$3,$4}'>>${errdir}/${appname}_busyservererr_${curusr}_${infdate}
            fi
    fi
    ;;
    -s)
    cat /dev/null>${tmpdir}/infoservtmp_${curusr}
    chmod 666 ${tmpdir}/infoservtmp_${curusr}
    cat /dev/null>${tmpdir}/infoserv_${curusr}
    chmod 666 ${tmpdir}/infoserv_${curusr}
    cat /dev/null>${tmpdir}/servtoltmp_${curusr}
    chmod 666 ${tmpdir}/servtoltmp_${curusr}
    cat /dev/null>${tmpdir}/servtol_${curusr}
    chmod 666 ${tmpdir}/servtol_${curusr}
    date +"%Y%m%d">${tmpdir}/date_server_${curusr}
    svrdate=`cat ${tmpdir}/date_server_${curusr}`
    #get config model information
    model=`cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "MODEL"|awk '{print $2}'|sed 's/[[:space:]]//g'`
    #SHM model get psr command information
    if [ "$model" = "SHM" ]
        then
            echo "servers info              "
            if [ "$curusr" = "root" ]
                then
                    psrsinfo_2
                else
                    psrsinfo
            fi
            if [ $? -eq 0 ]
                then
                    bnum=`cat ${tmpdir}/infoservtmp_${curusr}|grep -n "> Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                    bnum=`expr $bnum - 1`
                    enum=`cat ${tmpdir}/infoservtmp_${curusr}|grep -n ">"|grep -v "Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                    enum=`expr $enum + 1`
                    cat ${tmpdir}/infoservtmp_${curusr}|sed -n "$bnum,${enum}p">${tmpdir}/infoserv_${curusr}
                    errornum=`cat ${tmpdir}/infoserv_${curusr}|grep "ERROR:"|wc -l`
                    warnnum=`cat ${tmpdir}/infoserv_${curusr}|grep "WARN:"|wc -l`
                    if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                        then
                            echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                            echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${svrdate}
                            if [ $errornum -ne 0 ]
                                then
                                    cat ${tmpdir}/infoservtmp_${curusr}|grep "ERROR:"
                            fi
                            if [ $warnnum -ne 0 ]
                                then
                                    cat ${tmpdir}/infoservtmp_${curusr}|grep "WARN:"
                            fi
                            exit $STATE_WARNING
                    fi
                    servnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|sed '/^$/d'|awk '{print $1}'|uniq -c|wc -l|sed 's/[[:space:]]//g'`
                    cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|sed '/^$/d'|awk '{print $1}'|sed 's/[[:space:]]//g'|sort|uniq -c>${tmpdir}/servtoltmp_${curusr}
                    if [ $servnum -ne 0 ]
                        then
                        n=1
                        while [ $n -le $servnum ]
                        do
                            servname=`awk -v a=$n 'NR==a {print $2}' ${tmpdir}/servtoltmp_${curusr}|sed 's/[[:space:]]//g'`
                            servtolnum=`awk -v a=$n 'NR==a {print $1}' ${tmpdir}/servtoltmp_${curusr}|sed 's/[[:space:]]//g'`
                            servidlnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|grep IDLE|wc -l|sed 's/[[:space:]]//g'`
                            servbusnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|awk '$8 !~ /^IDLE$/ {print $0}'|wc -l|sed 's/[[:space:]]//g'`
                            #servbusnum=$((servtolnum-servidlnum))
                            servreqnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|awk '{ c=c+$5} END {print c}'`
                            echo $servname|awk -v a=$servname -v b=$servtolnum -v c=$servidlnum -v d=$servbusnum -v e=$servreqnum '{printf "%s %s %s %s %s\n",a,b,c,d,e}'>>${tmpdir}/servtol_${curusr}
                            n=`expr $n + 1`
                        done
                    fi
                else
                    echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                    echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${svrdate}
                    exit $STATE_WARNING
            fi
        else
            #MP model get psr command information
            cat ${tmpdir}/tmconftmp_${curusr}_${chose}|grep "MASTER"|awk '{print $2}'|sed 's/"//g'|tr , \\n>${tmpdir}/master_tmp_${curusr}
            masternum=`cat ${tmpdir}/master_tmp_${curusr}|wc -l`
            p=1
            while [ $p -le $masternum ]
            do
                site=`awk -v a=$p 'NR==a {print $1}' ${tmpdir}/master_tmp_${curusr}|sed 's/[[:space:]]//g'`
                cat /dev/null>${tmpdir}/servtol_${site}_${curusr}
                if [ "$curusr" = "root" ]
                    then
                        mppsrinfo_2
                    else
                        mppsrinfo
                fi
                if [ $? -eq 0 ]
                    then
                        bnum=`cat ${tmpdir}/infoservtmp_${curusr}|grep -n "$site> Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                        bnum=`expr $bnum - 1`
                        enum=`cat ${tmpdir}/infoservtmp_${curusr}|grep -n "$site>"|grep -v "Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
                        enum=`expr $enum + 1`
                        cat ${tmpdir}/infoservtmp_${curusr}|sed -n "$bnum,${enum}p">${tmpdir}/infoserv_${curusr}
                        errornum=`cat ${tmpdir}/infoserv_${curusr}|grep "ERROR:"|wc -l`
                        warnnum=`cat ${tmpdir}/infoserv_${curusr}|grep "WARN:"|wc -l`
                        if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                            then
                                echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                                echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${svrdate}
                                if [ $errornum -ne 0 ]
                                    then
                                        cat ${tmpdir}/infoservtmp_${curusr}|grep "ERROR:"
                                fi
                                if [ $warnnum -ne 0 ]
                                    then
                                        cat ${tmpdir}/infoservtmp_${curusr}|grep "WARN:"
                                fi
                                exit $STATE_WARNING
                        fi
                        servnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|sed '/^$/d'|awk '{print $1}'|uniq -c|wc -l|sed 's/[[:space:]]//g'`
                        cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|sed '/^$/d'|awk '{print $1}'|sed 's/[[:space:]]//g'|sort|uniq -c>${tmpdir}/servtoltmp_${curusr}
                        if [ $servnum -ne 0 ]
                            then
                            n=1
                            while [ $n -le $servnum ]
                            do
                                servname=`awk -v a=$n 'NR==a {print $2}' ${tmpdir}/servtoltmp_${curusr}|sed 's/[[:space:]]//g'`
                                servtolnum=`awk -v a=$n 'NR==a {print $1}' ${tmpdir}/servtoltmp_${curusr}|sed 's/[[:space:]]//g'`
                                servidlnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|grep IDLE|wc -l|sed 's/[[:space:]]//g'`
                                servbusnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|awk '$8 !~ /^IDLE$/ {print $0}'|wc -l|sed 's/[[:space:]]//g'`
                                #servbusnum=$((servtolnum-servidlnum))
                                servreqnum=`cat ${tmpdir}/infoserv_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'|awk -v  a=$servname '$1==a {print $0}'|awk '{ c=c+$5} END {print c}'`
                                echo $servname|awk -v a=$servname -v b=$servtolnum -v c=$servidlnum -v d=$servbusnum -v e=$servreqnum '{printf "%s %s %s %s %s\n",a,b,c,d,e}'>>${tmpdir}/servtol_${site}_${curusr}
                                n=`expr $n + 1`
                            done
                        fi
                    else
                        echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED"
                        echo "WARN:TMADMIN CONSOLE RUN psr COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${svrdate}
                        exit $STATE_WARNING
                fi
                p=`expr $p + 1`
            done
    fi
    if [ "$model" = "SHM" ]
        then
            #show the shm model monitor information
            echo "Servers Name   Run Num    Idl Num   NIdl Num   Req Num         "
            echo "------------   -------    -------   --------   -------         "
            cat ${tmpdir}/servtol_${curusr}|awk '{printf "%-15s%-11s%-10s%-11s%-ld\n",$1,$2,$3,$4,$5}'|sed '/^0/d'|sed '/^BBL/d'|sed '/^GWTDOMAIN/d'|sed '/^DMADM/d'|sed '/^GWADM/d'|sed '/^WSL/d'|sed '/^JSL/d'
            #write log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/server_current_time
                    server_time=`cat ${tmpdir}/server_current_time`
                    cat ${tmpdir}/servtol_${curusr}|sed '/^ /d'|awk -v a=$server_time '{printf "%s|%s|%s|%s|%s|%ld\n",a,$1,$2,$3,$4,$5}'|sed '/|BBL|/d'|sed '/|GWTDOMAIN|/d'|sed '/|DMADM|/d'|sed '/|GWADM|/d'|sed '/|WSL|/d'|sed '/|JSL|/d'>>${logdir}/${appname}_server_${curusr}_${svrdate}
            fi
        else
            #show the mp model monitor information
            machnum=`cat ${tmpdir}/master_tmp_${curusr}|wc -l`
            q=1
            while [ $q -le $machnum ]
            do
                site=`awk -v a=$q 'NR==a {print $1}' ${tmpdir}/master_tmp_${curusr}|sed 's/[[:space:]]//g'`
                echo "$site machine servers info                                     "
                echo "Servers Name   Run Num    Idl Num   NIdl Num   Req Num         "
                echo "------------   -------    -------   --------   -------         "
                cat ${tmpdir}/servtol_${site}_${curusr}|awk '{printf "%-15s%-11s%-10s%-11s%-ld\n",$1,$2,$3,$4,$5}'|sed '/^0/d'|sed '/^BBL/d'|sed '/^GWTDOMAIN/d'|sed '/^DMADM/d'|sed '/^GWADM/d'|sed '/^WSL/d'|sed '/^JSL/d'
                echo ""
                #write log file
                if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/server_current_time
                    server_time=`cat ${tmpdir}/server_current_time`
                    cat ${tmpdir}/servtol_${site}_${curusr}|sed '/^ /d'|awk -v a=$server_time '{printf "%s|%s|%s|%s|%s|%ld\n",a,$1,$2,$3,$4,$5}'|sed '/|BBL|/d'|sed '/|GWTDOMAIN|/d'|sed '/|DMADM|/d'|sed '/|GWADM|/d'|sed '/|WSL|/d'|sed '/|JSL|/d'>>${logdir}/${appname}_server_${site}_${curusr}_${svrdate}
                fi
                q=`expr $q + 1`
            done
    fi
    ;;
		-d)
		cat /dev/null>${tmpdir}/dmrotcontmp_${curusr}
    chmod 666 ${tmpdir}/dmrotcontmp_${curusr}
		cat /dev/null>${tmpdir}/dmrotdistmp_${curusr}
    chmod 666 ${tmpdir}/dmrotdistmp_${curusr}
		date +"%Y%m%d">${tmpdir}/date_domain_${curusr}
    domdate=`cat ${tmpdir}/date_domain_${curusr}`
		#domain informations
		#locdomain informations
    bnum=`cat ${tmpdir}/dmconftmp_${curusr}_${chose}|grep -n "*DM_LOCAL"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
    enum=`cat ${tmpdir}/dmconftmp_${curusr}_${chose}|grep -n "*DM_REMOT"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
    bnum=`expr $bnum + 1`
    enum=`expr $enum - 1`  
    cat ${tmpdir}/dmconftmp_${curusr}_${chose}|sed -n "$bnum,${enum}p"|sed '/^$/d'|grep "GWGRP"|grep -v "#"|awk '{print $1}'|sed 's/\"//g'|sed 's/[[:space:]]//g'>${tmpdir}/dmloctmp_${curusr}
    chmod 666 ${tmpdir}/dmloctmp_${curusr}
    i=`wc -l ${tmpdir}/dmloctmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
    #rotdomain informations
    bnum=`cat ${tmpdir}/dmconftmp_${curusr}_${chose}|grep -n "*DM_REMOT"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
    enum=`cat ${tmpdir}/dmconftmp_${curusr}_${chose}|grep -n "*DM_TDOMA"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
    bnum=`expr $bnum + 1`
    enum=`expr $enum - 1`
    cat ${tmpdir}/dmconftmp_${curusr}_${chose}|sed -n "$bnum,${enum}p"|sed '/^$/d'|grep "ACCESS"|grep -v "#"|awk '{print $1}'|sed 's/\"//g'|sed 's/[[:space:]]//g'>${tmpdir}/dmrottmp_${curusr}
    chmod 666 ${tmpdir}/dmrottmp_${curusr}
    j=`wc -l ${tmpdir}/dmrottmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
    echo "domains info               "
    if [ "$i" -ne 0 ]
    then
        k=1
        while [ "$k" -le "$i" ]
        do
            locdom=`awk -v a=$k 'NR==a {print $1}' ${tmpdir}/dmloctmp_${curusr}`
            cat /dev/null>${tmpdir}/${locdom}tmp_${curusr}
            chmod 666 ${tmpdir}/${locdom}tmp_${curusr}
            if [ "$curusr" = "root" ]
                then
                    dminfo_2
                else
                    dminfo
            fi
            if [ $? -eq 0 ]
                then
                    disnum=`grep "Disconnected" ${tmpdir}/${locdom}tmp_${curusr}|wc -l|sed  's/[[:space:]]//g'`
                    bnum=`cat ${tmpdir}/${locdom}tmp_${curusr}|grep -n "Connected"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
                    enum=`cat ${tmpdir}/${locdom}tmp_${curusr}|sed '1d'|grep -n '^$'|head -n 1|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
                    bnum=`expr $bnum + 1`
                    enum=`expr $enum + 1`
                    #echo $bnum $enum
                    if [ $bnum -ne $enum ]
                        then
                            cat ${tmpdir}/${locdom}tmp_${curusr}|sed -n "$bnum,${enum}p"|sed '/^$/d'|awk -F":" '{print $2}'|sed  's/[[:space:]]//g'>>${tmpdir}/dmrotcontmp_${curusr}
                    fi
                else
                    echo "WARN:DMADMIN CONSOLE RUN pd -d $locdom COMMAND FAILED"
                    echo "WARN:DMADMIN CONSOLE RUN pd -d $locdom COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${domdate}
                    exit $STATE_WARNING
            fi
            if [ "$disnum" -ne 0 ]
                then
                    bnum=`cat ${tmpdir}/${locdom}tmp_${curusr}|grep -n "Disconnected"|awk -F":" '{print $1}'|sed  's/[[:space:]]//g'`
                    enum=`wc -l ${tmpdir}/${locdom}tmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
                    bnum=`expr $bnum + 1`
                    enum=`expr $enum - 1`
                    cat ${tmpdir}/${locdom}tmp_${curusr}|sed -n "$bnum,${enum}p"|sed '/^$/d'|grep -v ">"|awk -F":" '{print $2}'|sed  's/[[:space:]]//g'>${tmpdir}/dmrot${locdom}tmp_${curusr}
                    chmod 666 ${tmpdir}/dmrot${locdom}tmp_${curusr}
                    echo $locdom|awk -v a=$locdom -v b=${tmpdir}/dmrot${locdom}tmp_${curusr} '{printf "sed \047s/^/%s    /g\047 %s\n",a,b}'|sh|sed 's/$/    discon/g'>>${tmpdir}/dmrotdistmp_${curusr}
            fi
            k=`expr $k + 1`
        done
        disnum=`wc -l ${tmpdir}/dmrotdistmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
        derrfile=${errdir}/${appname}_derr_${curusr}_${domdate}
        if [ -e ${derrfile} ]
            then
                derrfile=${errdir}/${appname}_derr_${curusr}_${domdate}
            else
                cat /dev/null>${errdir}/${appname}_derr_${curusr}_${domdate}
        fi
        if [ $disnum -ne 0 ]
            then
                date +"%H:%M">${tmpdir}/domain_current_time
                domain_time=`cat ${tmpdir}/domain_current_time`
                echo "">>${errdir}/${appname}_derr_${curusr}_${domdate}
                echo ${domain_time}" WARN: TOP 10 DISCONNECTED DOMAIN INFO    ">>${errdir}/${appname}_derr_${curusr}_${domdate}
                echo "loc_dom          rot_dom           status">>${errdir}/${appname}_derr_${curusr}_${domdate}
                echo "-------          -------           ------">>${errdir}/${appname}_derr_${curusr}_${domdate}
                cat ${tmpdir}/dmrotdistmp_${curusr}|head -n 10|awk '{printf "%-10s       %-10s        %-10s      \n",$1,$2,$3}'>>${errdir}/${appname}_derr_${curusr}_${domdate}
                echo ""
                #write err log file
                if [ "$2" = "-log" ]
                    then
                        date +"%H:%M">${tmpdir}/domain_current_time
                        domain_time=`cat ${tmpdir}/domain_current_time`
                        cat ${tmpdir}/dmrotdistmp_${curusr}|awk -v a=$domain_time '{printf "%s|%s|%s|%s\n",a,$1,$2,$3}'>>${errdir}/${appname}_domainserr_${curusr}_${domdate}
                fi
        fi
    fi
    disnum=`wc -l ${tmpdir}/dmrotdistmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
    connum=`wc -l ${tmpdir}/dmrotcontmp_${curusr}|awk '{print $1}'|sed  's/[[:space:]]//g'`
    
    echo "loc_dom_num     rot_dom_num     total_con_num     total_discon_num"
    echo "-----------     -----------     -------------     ----------------"
    echo $i|awk -v a=$i -v b=$j -v c=$connum -v d=$disnum '{printf "%-12s    %-12s    %-12s      %-12s  \n",a,b,c,d}'
    #write log file
    if [ "$2" = "-log" ]
        then
            date +"%H:%M">${tmpdir}/domain_current_time
            domain_time=`cat ${tmpdir}/domain_current_time`
            echo $i|awk -v a=$i -v b=$j -v c=$connum -v d=$disnum -v e=$domain_time '{printf "%s|%s|%s|%s|%s\n",e,a,b,c,d}'>>${logdir}/${appname}_domains_${curusr}_${domdate}
    fi
		;;
		-q)
		cat /dev/null>${tmpdir}/infosquetmp_${curusr}
    chmod 666 ${tmpdir}/infosquetmp_${curusr}
    cat /dev/null>${tmpdir}/infosque_${curusr}
    chmod 666 ${tmpdir}/infosque_${curusr}
    cat /dev/null>${tmpdir}/quename_tmp_${curusr}
    chmod 666 ${tmpdir}/quename_tmp_${curusr}
    cat /dev/null>${tmpdir}/quename_${curusr}
    chmod 666 ${tmpdir}/quename_${curusr}
    cat /dev/null>${tmpdir}/infosquetmp2_${curusr}
    chmod 666 ${tmpdir}/infosquetmp2_${curusr}
		#get pq command information
		date +"%Y%m%d">${tmpdir}/date_queue_${curusr}
    quedate=`cat ${tmpdir}/date_queue_${curusr}`
    if [ "$curusr" = "root" ]
        then
            pqqinfo_2
            getquename2
        else
            pqqinfo
            getquename
    fi
    #if the function run failed given the warning information
    if [ $? -eq 0 ]
        then
            bnum=`cat ${tmpdir}/infosquetmp_${curusr}|grep -n "> Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            bnum=`expr $bnum - 1`
            enum=`cat ${tmpdir}/infosquetmp_${curusr}|grep -n ">"|grep -v "Prog"|awk -F":" '{print $1}'|sed 's/[[:space:]]//g'`
            enum=`expr $enum + 1`
            cat ${tmpdir}/infosquetmp_${curusr}|sed -n "$bnum,${enum}p">${tmpdir}/infosque_${curusr}
            cat ${tmpdir}/quename_tmp_${curusr}|grep "Queue Name"|awk -F":" '{print $2}'|sed 's/[[:space:]]//g'>${tmpdir}/quename_${curusr}
            cat ${tmpdir}/infosque_${curusr}|sed '1,3d'|grep -v ">"|sed '$d'>${tmpdir}/infosquetmp2_${curusr}
            paste ${tmpdir}/infosquetmp2_${curusr} ${tmpdir}/quename_${curusr}>${tmpdir}/infosque_${curusr}
            errornum=`cat ${tmpdir}/infosquetmp_${curusr}|grep "ERROR:"|wc -l`
            warnnum=`cat ${tmpdir}/infosquetmp_${curusr}|grep "WARN:"|wc -l`
            if [ $errornum -ne 0 -o $warnnum -ne 0 ]
                then
                    echo "WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED"
                    echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${quedate}
                    if [ $errornum -ne 0 ]
                        then
                            cat ${tmpdir}/infosquetmp_${curusr}|grep "ERROR:"
                    fi
                    if [ $warnnum -ne 0 ]
                        then
                            cat ${tmpdir}/infosquetmp_${curusr}|grep "WARN:"
                    fi
                    exit $STATE_WARNING
            fi
            echo "Queue_Name                  Prog_Name        # Server   # Queued   Machine"
            echo "-------------------------   --------------   --------   --------   -------"
            cat ${tmpdir}/infosque_${curusr}|sed '$d'|grep -v "GWTDOMAIN"|grep -v "GWADM"|grep -v "DMADM"|grep -v "BBL"|awk '{printf "%-25s   %-14s   %-5ld      %-11ld%-s\n",$8,$1,$3,$5,$7}'
            #write log file
            if [ "$2" = "-log" ]
                then
                    date +"%H:%M">${tmpdir}/que_current_time
                    que_time=`cat ${tmpdir}/que_current_time`
                    cat ${tmpdir}/infosque_${curusr}|grep -v "GWTDOMAIN"|grep -v "GWADM"|grep -v "DMADM"|grep -v "BBL"|awk -v a=$que_time '{printf "%s|%s|%s|%ld|%ld|%s\n",a,$8,$1,$3,$5,$7}'>>${logdir}/${appname}_que_${curusr}_${quedate}
            fi
        else
            echo "WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED"
            echo ${mon_time}"|WARN:TMADMIN CONSOLE RUN pq COMMAND FAILED">>${errdir}/${appname}_otherr_${curusr}_${quedate}
            exit $STATE_WARNING
    fi
		;;
esac


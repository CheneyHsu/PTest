#!/bin/sh

#*********************** GeneralCheck ENV ************************
export BASE_ROOT=/home/sysadmin/toolbox/midware
export TOOL_ROOT=${BASE_ROOT}/bin/TOOLS
export TOOL_TMP=${BASE_ROOT}/tmp
export TOOL_CONF=${BASE_ROOT}/conf
#********************** CUSTOM SCRIPT ****************************
export WEBLOGIC_NORMAL=false
export CUSTOM_LOG_PATH=${TOOL_CONF}/domains_conf
export LOG_PATH=/weblogic/wlslogs
export GENERAL_LOG_FILE=${TOOL_TMP}/GeneralCheck.log
export KEY_CONF=${TOOL_CONF}/key_conf
#!/usr/bin/ksh
# set -x
# Version 2.2  
# 2013-08-03 13:30 Updated by Yecho ^-^! 
############################################
cd /home/sysadmin/toolbox
/home/sysadmin/toolbox/setenv.sh
#--------------
CmdDIR=./bin
MDIR=./log
tag=`date +%m%d`
TARDIR=$MDIR
LogFile=$MDIR/tools.log

file $TARDIR | grep open  > /dev/null
if [  $? -eq 0 ] ; then
   mkdir -p $TARDIR
   chmod 777 $TARDIR
fi

while :
do       #01
    cat config | while read myline
    do    #02
    #����һ���˵�
        trap "echo PROGRAM TERMINATE!" INT
        menu=`echo $myline|grep -v '#' | awk 'length($1) <= 2 {print $1}'`
        des=`echo $myline|grep -v '#' | awk 'length($1) <= 2 {print $2}'`
     
        if [ $menu ]
        then
             if [ ${menu} -eq 1 ]
             then
               clear
               echo "                                                       "
               echo "                                                 V3.41 "
               echo "           Level 1:  ALL functional menu               "
               echo "          =============================================  " 
            fi
               echo '             '$menu':' $des'                              '
        fi
    done
  #02
               echo "           Q/q: QUIT                                    "
               echo "          =============================================  "
               echo  "Choose a number or character:" 
            read NUM
	    NUM1=$NUM
    if [ ${NUM} = q -o ${NUM} = Q ]     #03
    then
        exit;
    else	
		  menu1=`cat config|grep ^${NUM}" "`                             # ȡ�˵�����
		  menudes1=`echo ${menu1} |awk '{print $1}'`                     # ȡ�˵���
		  des1=`echo ${menu1} |awk '{print $2}'`                         # ȡ�˵�������
	          systype1=`echo ${menu1} |awk '{print $3}'`                 #�˵�ȡ���� 

   		  if [ ! -n "${systype1}" ]
		  then
		      echo "Please check your entry!"
		  	#  break
		      continue
		  fi

		  if [ ${systype1} = 1 -o ${systype1} = 2 -o ${systype1} = 3 ]
   	          then
	              echo "Menu type is currect" >> $LogFile
                  else	
		      break
		  fi	
		  
	    if [ ${systype1} -eq 2 -o ${systype1} = 3 ]                      #   05
	    then
	        if [ ${systype1} -eq 2  ]                                     #�����2��ִ������ű�
	        then
	            syssh=`echo ${menu1} |awk '{print $4}'`
			     clear
			     $CmdDIR/${syssh} $TARDIR
                             echo " "
			     echo "Press enter button return"
	            read
                    echo "Execute script:${syssh}"	>> $LogFile		 
                else	             
                    if [ ${systype1} -eq 3 ]                                       #  �����3��ִ���������� 
	            then
	                syssh=`echo ${menu1} |awk '{print $4}'`
			     clear
			     ${syssh}
			     echo "Execute command:${syssh}"	>> $LogFile		 
                    fi
                fi
            else	                                                      # ������Ϊ1ʱ�������ɶ����˵���
	                                                                      #����2���˵� 

       case $NUM in		 		 
       ${NUM})
             
        while :
        do	     #07
                                                                         #�����ļ���ȡ�����˵�����	
	             clear
	     echo "                                                                   "
             echo "                                                                   "
             echo "            Level 2: ${des1} sub-menu          "
             echo "          =============================================  " 				   
                   cat config |grep -v '#' | grep ^${NUM}-[0-9a-z]" "| while read myline1    
                    do      #08
                       	suoyin1=`echo $myline1|awk '{print $1}'`               #   �˵���
                        cmddes1=`echo $myline1|awk '{print $2}'`               #   ����˵�����
             echo '             '$suoyin1':' $cmddes1'                      '
                    done     #08
             echo "             Q/q: Quit                                   "
             echo "          =============================================  "
                    echo  "Choose a number or character: " 
                    read NUMD	     					
				NUM2=$NUMD		
	
	                                                                           #��3��˵���ʼ				
      	         if [ ${NUMD} = q -o ${NUMD} = Q ]     #03
                 then
		        break;
                 else	
                 #         clear
		       menu2=`cat config|grep ^${NUM1}-${NUM2}" "`                       # ȡ�˵�ѡ��
		       menudes2=`echo ${menu2} |awk '{print $1}'`                        #ȡ�˵�
		       des2=`echo ${menu2} |awk '{print $2}'`                            # ȡ�˵�������
	               systype2=`echo ${menu2} |awk '{print $3}'`                    #�˵�ȡ���� 
		       if [ ! -n "${systype2}" ]
		       then
		         echo "Please check your entry!"
			     continue
		       fi
		       if [ ${systype2} = 1 -o ${systype2} = 2 -o ${systype2} = 3 ]
	               then
	                   echo "Menu type is currect" >> $LogFile	
                       else	
		           break
		       fi 
          
                       if [ ${systype2} -eq 2 -o ${systype2} = 3 ]                 #   05
	               then
	                   if [ ${systype2} -eq 2  ]                                   #�����2��ִ������ű�
	                   then
	                       syssh=`echo ${menu2} |awk '{print $4}'`
	                       clear
			            $CmdDIR/${syssh} $TARDIR
                                    echo " "
			            echo "Press enter any button return"
	                        read
                                echo "Execute script: ${syssh}"	>> $LogFile
                            else	             
                                if [ ${systype2} -eq 3 ]                            #  �����3��ִ���������� 
	                        then
	                            syssh=`echo ${menu2} |awk '{print $4}'`
		                    clear
		                    ${syssh}
		                    echo "Execute command: ${syssh}"	>> $LogFile
                                fi
                            fi             
                       else	                                                       # ������Ϊ1ʱ�������ɲ˵���
	                                                                               #�����¼��˵�  
                       case $NUMD in		 		 
                       ${NUMD})
	    	       while :
                       do	     #07
                           clear
                           echo "                                                         "
                           echo "                                                         "
                           echo "             Level 3: ${des2} sub-menu       "
                           echo "          =============================================  "
                                    #�����ļ���ȡ�����˵�����			  
                           cat config |grep -v '#' | grep ^${NUM1}-${NUM2}-[0-9a-z]" "| while read myline1    
                           do      #08
                               suoyin2=`echo $myline1|awk '{print $1}'`                #   ����˵���
                               cmddes2=`echo $myline1|awk '{print $2}'`                #   ����˵�����
                           echo '             '$suoyin2':' $cmddes2'                   '
                           done     #08
                           echo "               Q/q: Quit                                 "
                           echo "          =============================================  "
                           echo  "Choose a number or character:  " 
                           read NUMB
#-----------------------
				NUM3=$NUMB					
				#  														
				#���Ĳ�˵���ʼ				

					 if [ ${NUMB} = q -o ${NUMB} = Q ]     #03
					 then
						  #echo "��������"
							  break;
					 else	
						menu3=`cat config|grep ^${NUM1}-${NUM2}-${NUM3}" "`   # ȡ�˵�ѡ��
							menudes3=`echo ${menu3} |awk '{print $1}'`        #ȡ�˵�
							des3=`echo ${menu3} |awk '{print $2}'`       # ȡ�˵�������
						  systype3=`echo ${menu3} |awk '{print $3}'`    #�˵�ȡ���� 

						   if [ ! -n "${systype3}" ]
							 then
								echo "Please check your entry!"
							   continue
							 fi
							 if [ ${systype3} = 1 -o ${systype3} = 2 -o ${systype3} = 3 ]
						   then
							echo "Menu type is currect" >> $LogFile		
						 else	
							   break
							 fi 
					  
						   if [ ${systype3} -eq 2 -o ${systype3} = 3 ]                  #   05
						   then
						       if [ ${systype3} -eq 2  ]   #�����2��ִ������ű�
							 then
							   syssh=`echo ${menu3} |awk '{print $4}'`
								   clear
								   $CmdDIR/${syssh} $TARDIR
								   echo "Press enter button return"
							   read
								echo "Execute script: ${syssh}"	>> $LogFile
						   else	             
							if [ ${systype3} -eq 3 ]                  #  �����3��ִ���������� 
							  then
							   syssh=`echo ${menu3} |awk '{print $4}'`
								   clear
								   ${syssh}
								   echo "Execute command: ${syssh}"	>> $LogFile
							fi
						    fi

						   else	             # ������Ϊ1ʱ�������ɲ˵���
						   
				#�����¼��˵�  
						 case $NUMB in		 		 
						 ${NUMB})
							 while :
						 do	     #07
						   clear
						   echo "                                                                   "
						   echo "                                                                   "
						   echo "                                                                   "
						   echo "                         Level 4: ${des3} sub-menu     "
						   echo "                    =============================================  "
						   #�����ļ���ȡ�ļ��˵�����			  
					   cat config |grep -v '#' | grep ^${NUM1}-${NUM2}-${NUM3}-[0-9]" "| while read myline1    
							 do      #08
								suoyin3=`echo $myline1|awk '{print $1}`    #   ����˵���
								cmddes3=`echo $myline1|awk '{print $2}`     #   ����˵�����
								echo '                       '$suoyin3':'$cmddes3'    ' 
							 done     #08
						   echo "                       Q. Quit                                     "
						   echo "                    =============================================  "
						   echo  "Choose a number or character:  " 
						   read NUME	
#-----------------------			   
			   NUM6=$NUME		
	                   case $NUME in
                                              #��ȡ�˵������-��û�д���              				         
                           q|Q) break;;
                           *)	
                               echo "This is last level"
                           ;;						
                           esac
                       done       #07
		       ;;
		       esac   
		      fi             # 05
	         fi             # 03
                       done       #07
		       ;;
		       esac   
		      fi             # 05
	         fi             # 03					 
                                                                       #			
                                                                       #���������			
         done       #07
        ;;
        esac   
        fi         # 05
    fi             # 03
done


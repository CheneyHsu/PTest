#!/bin/sh
case $(uname) in
  Linux)  ECHO="echo -e"
  ;;
  *)      ECHO="echo"
  ;;
esac

case `uname` in
  HP-UX)
	PATH=/usr/sbin:/usr/bin:/opt/perf/bin:/opt/VRTSvcs/bin:/opt/VRTS/bin:/usr/openv/netbackup/bin:/usr/openv/netbackup/bin/admincmd:/usr/openv/netbackup/bin/goodies:$PATH:.
	export PATH
    ;;
  AIX)
	PATH=/usr/bin:/etc:/usr/sbin:/opt/VRTS/bin:/opt/VRTSvcs/bin:/usr/openv/netbackup/bin:/usr/openv/netbackup/bin/admincmd:/usr/openv/netbackup/bin/goodies:$PATH:.
	export PATH
    ;;
  Linux)
	PATH=/opt/perf/bin:/sbin:/usr/sbin:/usr/local/sbin:/root/bin:/usr/local/bin:/usr/bin:/bin:/opt/VRTSvcs/bin:/opt/VRTS/bin:/usr/openv/netbackup/bin:/usr/openv/netbackup/bin/admincmd:/usr/openv/netbackup/bin/goodies:$PATH:.
	export PATH 
    ;; 
  *)  
	$ECHO "\nUneupported Operation System for this Script... EXITING\n" 
        exit 1 
esac

set pagesize 0 heading off feed off
col STATUS        for a10
select status from v$instance;
exit

select 
dummy,
count(*)  
from dual group by dummy;
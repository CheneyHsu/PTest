#!/usr/bin/ksh

##########################
#   Volume Group Setting
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

VG_CONF=${CONF_PATH}/vg.conf
lsvg -o > ${VG_CONF}
a=$?
if [ $a -ne 0 ]
  then
    echo "101 vg.conf Setting:"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
  else
    echo "101 vg.conf Setting:"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi
echo "----------------------------------------------------------"

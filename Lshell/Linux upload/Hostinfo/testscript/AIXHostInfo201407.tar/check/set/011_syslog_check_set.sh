#!/usr/bin/ksh

###############################
#  syslog_check.conf Setting
###############################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf



SYSLOG_CONF=${CONF_PATH}/syslog_check.conf
if [ -f ${SYSLOG_CONF} ]
   then
     echo "011 ${SYSLOG_CONF} : already exists"
   else 
SYSNAME=`uname -n`

echo "EXCEPT=IDENTIFIER TIMESTAMP" >${CONF_PATH}/syslog_check.conf
echo "EXCEPT=SOFTWARE PROGRAM ABNORMALLY TERMINATED" >>${CONF_PATH}/syslog_check.conf
a=$?
   if [ $a -eq 0 ]
     then
       echo "011 syslog_check.conf Setting :"
       echo "......................................OK" | awk '{printf "%60s\n",$1}'
      else
        echo "011 syslog_check.conf Setting :"
        echo "...................................False" | awk '{printf "%60s\n",$1}'
    fi
fi
echo "----------------------------------------------------------"

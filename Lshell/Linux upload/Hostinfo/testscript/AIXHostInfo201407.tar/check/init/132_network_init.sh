#!/usr/bin/ksh

##########################
#  Initialize Network
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

NETSTAT_IN_SAMPLE=${SAMPLE_PATH}/netstat_in.sample
NETSTAT_RN_SAMPLE=${SAMPLE_PATH}/netstat_rn.sample
NETSTAT_V_SAMPLE=${SAMPLE_PATH}/netstat_v.sample
RET=0

netstat -in | awk '/en/p {print $1" "$3" "$4}' > ${NETSTAT_IN_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132_1 NETSTAT -IN Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=1
  else
    echo "132_1 NETSTAT -IN Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

netstat -rn |awk '{print $1" "$2}'> ${NETSTAT_RN_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132_2 NETSTAT -RN Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=`expr $RET +1`
  else
    echo "132_2 NETSTAT -RN Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi


netstat -v |grep -v "Elapsed Time: "|grep -v "Packets: "|grep -v "Bytes: "|grep -v "Interrupts:"|grep -v "TCP Segmentation Offload Packets Transmitted: "|grep -v Current |grep -v "Max Packets"|grep -v "Deferred:"|grep -v "XOFF Flow Control Packets Received" >${NETSTAT_V_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132_3 NETSTAT_V Initialization :"     
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=`expr $RET +1`
  else
    echo "132_3 NETSTAT_V Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

echo "----------------------------------------------------------"
echo

exit $RET

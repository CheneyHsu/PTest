#!/bin/ksh

###############################
#  syslog_check.conf Setting
###############################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf


SYSLOG_CONF=${CONF_PATH}/syslog_check.conf
if [ -f ${SYSLOG_CONF} ]
   then
     echo "011 ${SYSLOG_CONF} : already exists"
   else
     SYSNAME=`uname -n`
     echo "SYSLOG=/var/adm/syslog/syslog.log" >${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=" $SYSNAME "cimserver" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=" $SYSNAME "su" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=ftpd" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=sshd" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=above message repeats" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=synchronized to" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=LLT Protocol available" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=modld: Module already loaded" >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=GAB available"  >>${CONF_PATH}/syslog_check.conf
     echo "EXCEPT=/usr/sbin/lvlnboot" >>${CONF_PATH}/syslog_check.conf 
	 echo "EXCEPT=2OMNIBUS" >>${CONF_PATH}/syslog_check.conf
     if [ -f ${SYSLOG_CONF} ]
       then
         echo "011 syslog_check.conf :"
         echo "......................................OK" | awk '{printf "%60s\n",$1}'
       else
          echo "011 syslog_check.conf :"
         echo "...................................False" | awk '{printf "%60s\n",$1}'
      fi
fi
echo "----------------------------------------------------------"
echo
  

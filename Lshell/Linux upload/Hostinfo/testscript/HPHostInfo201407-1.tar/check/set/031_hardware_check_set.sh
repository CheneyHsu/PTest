#!/bin/ksh

###############################
#  031_hardware_check_set.sh Setting
###############################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf
HARDWARE=${CONF_PATH}/hardware_check.conf

if [ -f ${HARDWARE} ]
  then
    echo "031 ${HARDWARE} already exists"
  else
    cp ../set/hardware_check.conf ${CONF_PATH}
   if [ -f ${HARDWARE} ]
     then
       echo "031 hardware_check.conf :"
       echo "......................................OK" | awk '{printf "%60s\n",$1}'
      else
        echo "031 hardware_check.conf :"
        echo "...................................False" | awk '{printf "%60s\n",$1}'
    fi
fi
echo "----------------------------------------------------------"
echo
  

#!/bin/sh

##########################
#  Initialize Volume Group
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

VG_SAMPLE=${SAMPLE_PATH}/vgdisplay_v.sample
cat /dev/null >${VG_SAMPLE}
vgdisplay -v > ${VG_SAMPLE} 2>&1
if [ -z ${VG_SAMPLE} ]
  then
    echo "102 Volume Group Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
  else
    echo "102 Volume Group Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

echo "----------------------------------------------------------"
echo

exit 

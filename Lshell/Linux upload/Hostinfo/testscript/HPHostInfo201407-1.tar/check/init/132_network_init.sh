#!/bin/sh

##########################
#  Initialize Network
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

NETSTAT_IN_SAMPLE=${SAMPLE_PATH}/netstat_in.sample
NETSTAT_RVN_SAMPLE=${SAMPLE_PATH}/netstat_rvn.sample
LANSCAN_SAMPLE=${SAMPLE_PATH}/lanscan.sample
LANSCAN_Q_SAMPLE=${SAMPLE_PATH}/lanscan_q.sample
RET=0

netstat -in | awk '{print $1"	"$3"	"$4}' > ${NETSTAT_IN_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132 NETSTAT -IN Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=1
  else
    echo "132 NETSTAT -IN Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

netstat -rvn > ${NETSTAT_RVN_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132 NETSTAT -RVN Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=`expr $RET +1`
  else
    echo "132 NETSTAT -RVN Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

lanscan > ${LANSCAN_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132 LANSCAN Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=`expr $RET +1`
  else
    echo "132 LANSCAN Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

lanscan -q > ${LANSCAN_Q_SAMPLE}
a=$?
if [ $a -ne 0 ]
  then
    echo "132 LANSCAN -Q Initialization :"     
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    RET=`expr $RET +1`
  else
    echo "132 LANSCAN -Q Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

echo "----------------------------------------------------------"
echo

exit $RET

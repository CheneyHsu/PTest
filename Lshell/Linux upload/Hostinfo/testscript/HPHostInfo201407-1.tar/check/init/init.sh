#!/bin/sh

./042_setboot_init.sh
./052_cfg_group_init.sh
./062_cfg_hosts_init.sh
./072_cfg_passwd_init.sh
./082_cfg_kmtune_init.sh
./102_vg_init.sh
./132_network_init.sh


ps -ef |grep -q [o]ra_smon
a=$?
if [ $a = 0 ]
  then
   ./172_oracle_listener_init.sh
   ./182_oracle_lsnrctl_init.sh
  else
    echo  "172_oracle_listener_init.sh :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
    echo  "182_oracle_lsnrctl_init.sh :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
fi

if [ -x /opt/OV/bin/opctemplate ]
  then 
    ./152_ovo_init.sh
  else
    echo  "152_ovo_init.sh :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
fi


#./cluster_init.sh


if [ -x /sbin/powermt ]
  then
    ./212_powerpath_init.sh
  else
    echo  "212_powerpath_init.sh :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
fi

if [ -x /usr/symcli/bin/symrdf ]
  then
    ./222_srdf_init.sh
  else
    echo  "222_srdf_init.sh :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
fi


./242_cron.init.sh
./252_cfg_fstab_init.sh
./262_cfg_profile.sh


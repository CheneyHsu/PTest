select
comp_name,
version,
status 
from dba_registry;
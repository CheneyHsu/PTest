#!/usr/bin/ksh

##########################
#  Initialize Volume Group
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

VG_SAMPLE=${SAMPLE_PATH}/vg_
VG_CONF=${CONF_PATH}/vg.conf


cat ${VG_CONF} | while read i;
do
  lsvg ${i} > ${VG_SAMPLE}${i}.sample
#  lsvg -l ${i} |sed 's/closed/open/g' >> ${VG_SAMPLE}${i}.sample
  lsvg -l ${i} |awk '{print $1,$2,$3,$4,$5,$7}' >> ${VG_SAMPLE}${i}.sample
  a=$?
done

if [ $a -ne 0 ]
  then
    echo "102 Volume Group Initialization :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
  else
    echo "102 Volume Group Initialization :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi

echo "----------------------------------------------------------"
echo

exit 

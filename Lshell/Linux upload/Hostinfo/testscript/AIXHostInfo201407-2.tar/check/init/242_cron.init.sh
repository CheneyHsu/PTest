#!/bin/sh

############################################
# Cron Initialize 
############################################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf
CRONFILE=/var/spool/cron/crontabs


ls -i ${CRONFILE}|grep -v total | while read i;
  
do
  CRON_USER=`echo ${i} |awk '{print $NF}'`
  cat ${CRONFILE}/${CRON_USER} >${SAMPLE_PATH}/${CRON_USER}_cron.sample
  echo "242 ${CRON_USER}  Cron Initialize :"
  echo "...................................OK" | awk '{printf "%60s\n",$1}'

done


echo "----------------------------------------------------------"
echo

exit

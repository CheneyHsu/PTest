#!/usr/bin/ksh

##########################
#   Oracle Listener conf Setting
##########################
BIN_PATH=../bin
SAMPLE_PATH=../sample
TMP_PATH=../tmp
CONF_PATH=../conf

LSNRCTL_SETTING_TMP=${TMP_PATH}/lsnrctl_setting.tmp

ORACLE_LSNRCTL_CONF=${CONF_PATH}/oracle_lsnrctl_check.conf
ps -ef |grep -q [L]ISTENER
if [ $? -eq 0 ]
  then
#    ps -ef |grep [t]nslsnr |awk ' {print $1,substr($10, index($10, "R")+2)}' >${LSNRCTL_SETTING_TMP}
    ps -ef |grep [t]nslsnr |awk ' {print $1,$10}' >${LSNRCTL_SETTING_TMP}
  else
#    ps -ef |grep [t]nslsnr |awk ' {print $1,substr($10, index($10, "r")+2)}' >${LSNRCTL_SETTING_TMP}
    ps -ef |grep [t]nslsnr |awk ' {print $1,$10}' >${LSNRCTL_SETTING_TMP}
fi

cat /dev/null >${ORACLE_LSNRCTL_CONF}
cat ${LSNRCTL_SETTING_TMP} | while read i;
do
   ORACLE_USERS=`echo ${i} |awk '{print $1}'`
   LSNRCTL_NAME=`echo ${i} |awk '{print $2}'`

   echo "USER="${ORACLE_USERS} >>${ORACLE_LSNRCTL_CONF}
   echo "LISTENER="${LSNRCTL_NAME} >>${ORACLE_LSNRCTL_CONF}
   a=$?
done

if [ $a -ne 0 ]
  then
    echo "181 oracle_lsnrctl.conf  :"
    echo "...................................False" | awk '{printf "%60s\n",$1}'
    echo
  else
    echo "181 oracle_lsnrctl.conf :"
    echo "......................................OK" | awk '{printf "%60s\n",$1}'
fi
echo "----------------------------------------------------------"

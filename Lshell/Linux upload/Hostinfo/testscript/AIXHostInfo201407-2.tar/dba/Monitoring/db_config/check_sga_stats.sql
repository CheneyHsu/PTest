select * from v$sgastat
order by bytes;
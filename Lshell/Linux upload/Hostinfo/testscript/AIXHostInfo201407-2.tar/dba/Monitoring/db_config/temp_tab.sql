select tablespace_name,total_blocks,used_blocks,free_blocks 
from v$sort_segment;
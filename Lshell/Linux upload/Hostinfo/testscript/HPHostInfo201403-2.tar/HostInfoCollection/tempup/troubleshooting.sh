#!/bin/sh
#�鿴��û��troubleshootingĿ¼û�о����ع�����ѹ
CHECKDATE=`date "+%Y-%m-%d"`
export LANG=C

cd /home/sysadmin
TEMPUP=/home/sysadmin/HostInfoCollection/tempup
UPDATELOG=/home/sysadmin/HostInfoCollection/file/${CHECKDATE}_update.log
troubleshooting=/home/sysadmin/troubleshooting

if [ ! -d ${troubleshooting} ];then
  if [ `model|cut -c 1-2` = ia ];then
    if [ `uname -r` = "B.11.31" ];then
	  kk=`bdf |grep -w /home |awk '{printf "%d\n", ($(NF-3)+350000)/$(NF-4)*100}'`
	  if [ ${kk} -lt 80 ];then
	    
      echo "��ʼ����troubleshooting ���� " >>${UPDATELOG}
ftp  -v -n 10.200.8.87 <<EOF >>${UPDATELOG}
user  smdb smdbput
cd /smdb/shooting/HP
get troubleshooting.tar.gz
bye
EOF
      gzip -d troubleshooting.tar.gz >>${UPDATELOG} 2>&1  && tar xvf troubleshooting.tar >>${UPDATELOG} 2>&1
      if [ $? -eq 0 ];then
        echo "troubleshooting ���߲������" >>${UPDATELOG}
      else
        echo "troubleshooting ������������" >>${UPDATELOG}
      fi
	  test -f /home/sysadmin/troubleshooting.tar && rm /home/sysadmin/troubleshooting.tar  >>${UPDATELOG} 2>&1 
	  else 
	     echo "/home/ �ռ�̫С,troubleshooting�˳�����" >>${UPDATELOG}
	  fi
    fi
  fi
else  
  echo "troubleshooting �Ѵ���"   >>${UPDATELOG}
fi




